package br.com.santosmousegg

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SplashScreen() {
    var start by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { start = true }
    val p by animateFloatAsState(if (start) 1f else 0f, tween(1200), label = "splash")
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Crown(Modifier.size(width = 96.dp, height = 80.dp))
            Spacer(Modifier.height(12.dp))
            Text("SANTOS", fontSize = 44.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
            Text("MOUSE GG", fontSize = 34.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, color = Red)
            Spacer(Modifier.height(8.dp))
            Text("Mapeador • Clonador • Otimização", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(28.dp))
            LinearProgressIndicator(progress = { p }, color = Red, trackColor = Surface2, modifier = Modifier.width(200.dp))
        }
    }
}

@Composable
fun App() {
    var splash by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var adding by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(1400)
        splash = false
    }
    BackHandler(enabled = adding) { adding = false }

    if (splash) {
        SplashScreen()
    } else {
        val tabs = listOf(
            "Jogos" to Icons.Filled.SportsEsports,
            "Conta" to Icons.Filled.Person,
            "Clonador" to Icons.Filled.ContentCopy,
            "Configurações" to Icons.Filled.Settings
        )
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                if (!adding) {
                    NavigationBar(containerColor = Surface1) {
                        tabs.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Red,
                                    selectedTextColor = Red,
                                    indicatorColor = Surface2,
                                    unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    adding -> AddGameScreen(onBack = { adding = false })
                    tab == 0 -> GamesScreen(onAdd = { adding = true })
                    tab == 1 -> AccountScreen()
                    tab == 2 -> ClonerScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}
