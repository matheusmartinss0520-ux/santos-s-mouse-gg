package br.com.santosmousegg

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** A coroa, símbolo principal da marca. */
@Composable
fun Crown(modifier: Modifier = Modifier, color: Color = Red) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(0.125f * w, 0.9f * h)
            lineTo(0.042f * w, 0.25f * h)
            lineTo(0.271f * w, 0.45f * h)
            lineTo(0.5f * w, 0.05f * h)
            lineTo(0.729f * w, 0.45f * h)
            lineTo(0.958f * w, 0.25f * h)
            lineTo(0.875f * w, 0.9f * h)
            close()
        }
        drawPath(path, color)
    }
}

@Composable
fun Logo(fontSize: TextUnit = 20.sp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Crown(Modifier.size(width = (fontSize.value * 1.4).dp, height = (fontSize.value * 1.15).dp))
        Spacer(Modifier.width(8.dp))
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = Ink)) { append("SANTOS ") }
                withStyle(SpanStyle(color = Red)) { append("MOUSE GG") }
            },
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Italic
        )
    }
}

@Composable
fun NeonButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Red,
            contentColor = Color.White,
            disabledContainerColor = Surface2,
            disabledContentColor = Muted
        )
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, fontSize = 26.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
}

/** Cartão padrão: fundo escuro e borda discreta. */
fun Modifier.panel(): Modifier =
    this.background(Surface1, RoundedCornerShape(14.dp)).border(1.dp, LineColor, RoundedCornerShape(14.dp))

/** Desenho simples de câmera, no estilo do ícone do Instagram. */
@Composable
fun InstagramGlyph(modifier: Modifier = Modifier, color: Color = Ink) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.09f
        drawRoundRect(
            color = color,
            topLeft = Offset(sw / 2, sw / 2),
            size = Size(w - sw, w - sw),
            cornerRadius = CornerRadius(w * 0.28f),
            style = Stroke(width = sw)
        )
        drawCircle(color = color, radius = w * 0.2f, style = Stroke(width = sw))
        drawCircle(color = color, radius = w * 0.045f, center = Offset(w * 0.74f, w * 0.26f))
    }
}
