package br.com.santosmousegg

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.input.InputManager
import android.view.InputDevice
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap

/** Biblioteca de jogos: guarda só o nome do pacote de cada jogo, neste aparelho. */
object GameLibrary {
    private var loaded = false
    val games = mutableStateListOf<String>()

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("library", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val raw = prefs(ctx).getString("games", "") ?: ""
        games.addAll(raw.split("\n").filter { it.isNotBlank() })
    }

    private fun save(ctx: Context) {
        prefs(ctx).edit().putString("games", games.joinToString("\n")).apply()
    }

    fun add(ctx: Context, pkg: String) {
        if (pkg !in games) {
            games.add(pkg)
            save(ctx)
        }
    }

    fun remove(ctx: Context, pkg: String) {
        games.remove(pkg)
        save(ctx)
    }
}

class AppInfo(val pkg: String, val name: String, val icon: ImageBitmap)

/** Lista os apps instalados que têm ícone de abrir. */
fun loadLaunchable(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppInfo(
                it.activityInfo.packageName,
                it.loadLabel(pm).toString(),
                it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            )
        }
        .distinctBy { it.pkg }
        .sortedBy { it.name.lowercase() }
}

/** Nome e ícone de um app pelo pacote; null se não estiver instalado. */
fun appInfoOrNull(ctx: Context, pkg: String): AppInfo? {
    val pm = ctx.packageManager
    return try {
        val ai = pm.getApplicationInfo(pkg, 0)
        AppInfo(pkg, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai).toBitmap(96, 96).asImageBitmap())
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }
}

fun launchApp(ctx: Context, pkg: String): Boolean {
    val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}

