package br.com.santosmousegg

import android.content.Context
import android.hardware.input.InputManager
import android.view.InputDevice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class DevState { OFF, LIMITED, OK }

/**
 * Mouse e teclado físicos.
 * OFF = não encontrado, LIMITED = o Android listou o aparelho mas ainda não chegou nenhum evento dele,
 * OK = chegaram eventos de verdade (aparelho funcionando).
 */
object Devices {
    var mouse by mutableStateOf(DevState.OFF)
    var keyboard by mutableStateOf(DevState.OFF)
    var mouseInfo by mutableStateOf<List<String>>(emptyList())
    var keyboardInfo by mutableStateOf<List<String>>(emptyList())

    private var mouseSeen = false
    private var keySeen = false
    private var users = 0
    private var im: InputManager? = null

    private val listener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            refresh()
        }

        override fun onInputDeviceRemoved(deviceId: Int) {
            mouseSeen = false
            keySeen = false
            refresh()
        }

        override fun onInputDeviceChanged(deviceId: Int) {
            refresh()
        }
    }

    fun start(ctx: Context) {
        users++
        if (users == 1) {
            val m = ctx.getSystemService(Context.INPUT_SERVICE) as InputManager
            im = m
            m.registerInputDeviceListener(listener, null)
        }
        refresh()
    }

    fun stop() {
        if (users > 0) users--
        if (users == 0) {
            im?.unregisterInputDeviceListener(listener)
            im = null
        }
    }

    private fun has(s: Int, f: Int) = (s and f) == f

    private fun hex(v: Int) = String.format("%04x", v)

    fun refresh() {
        val mice = ArrayList<String>()
        val kbs = ArrayList<String>()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            val s = d.sources
            val info = "${d.name}\nVendor ${hex(d.vendorId)} • Produto ${hex(d.productId)} • Fontes 0x${Integer.toHexString(s)}"
            val pointer = has(s, InputDevice.SOURCE_MOUSE) || has(s, InputDevice.SOURCE_MOUSE_RELATIVE) ||
                has(s, InputDevice.SOURCE_TRACKBALL) || has(s, InputDevice.SOURCE_TOUCHPAD)
            if (pointer && !has(s, InputDevice.SOURCE_TOUCHSCREEN)) mice.add(info)
            if (has(s, InputDevice.SOURCE_KEYBOARD) && d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC) kbs.add(info)
        }
        mouseInfo = if (mice.isEmpty() && mouseSeen) {
            listOf("Eventos de mouse recebidos, mas o Android não listou o aparelho como mouse.")
        } else mice
        keyboardInfo = if (kbs.isEmpty() && keySeen) {
            listOf("Eventos de teclado recebidos, mas o Android não listou o aparelho como teclado físico.")
        } else kbs
        mouse = if (mouseSeen) DevState.OK else if (mice.isNotEmpty()) DevState.LIMITED else DevState.OFF
        keyboard = if (keySeen) DevState.OK else if (kbs.isNotEmpty()) DevState.LIMITED else DevState.OFF
    }

    fun markMouseSeen() {
        if (!mouseSeen) {
            mouseSeen = true
            refresh()
        }
    }

    fun markKeyboardSeen() {
        if (!keySeen) {
            keySeen = true
            refresh()
        }
    }
}
