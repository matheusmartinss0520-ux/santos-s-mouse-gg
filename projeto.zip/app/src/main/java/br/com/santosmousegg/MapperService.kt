package br.com.santosmousegg

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

private val NEON = Color.parseColor("#E5202E")
private val DARK = Color.parseColor("#F0150D0F")
private val GREEN = Color.parseColor("#32D27A")
private val AMBER = Color.parseColor("#FFC107")
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val NF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
private const val NT = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
private const val NM = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
private const val LS = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
private const val JOY_ID = -1000

private fun lpOf(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
    w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
).apply { gravity = Gravity.TOP or Gravity.START }

private fun colorOf(s: DevState) = when (s) {
    DevState.OK -> GREEN
    DevState.LIMITED -> AMBER
    DevState.OFF -> NEON
}

/** Um toque que está sendo segurado no jogo enquanto a tecla está apertada. */
class Hold(var x: Float, var y: Float) {
    var tx = x
    var ty = y
    var cx = x
    var cy = y
    var joy = false
    var stroke: GestureDescription.StrokeDescription? = null
    var release = false
}

/** Botão redondo com a coroa. */
class CrownView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#E60A0607")
        canvas.drawCircle(w / 2, h / 2, w / 2 - 3f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = NEON
        canvas.drawCircle(w / 2, h / 2, w / 2 - 3f, paint)
        val path = Path().apply {
            moveTo(0.28f * w, 0.68f * h); lineTo(0.20f * w, 0.34f * h); lineTo(0.36f * w, 0.46f * h)
            lineTo(0.50f * w, 0.26f * h); lineTo(0.64f * w, 0.46f * h); lineTo(0.80f * w, 0.34f * h)
            lineTo(0.72f * w, 0.68f * h); close()
        }
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
    }
}

/** Ícone de mouse ou teclado que muda de cor conforme o estado. */
class DeviceIcon(context: Context, private val keyboard: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var color: Int = Color.GRAY
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f
        p.color = color
        if (keyboard) {
            canvas.drawRoundRect(1f, h * 0.25f, w - 1f, h * 0.8f, 4f, 4f, p)
            p.style = Paint.Style.FILL
            for (i in 0..2) canvas.drawCircle(w * (0.25f + 0.25f * i), h * 0.45f, 1.6f, p)
            canvas.drawRect(w * 0.25f, h * 0.62f, w * 0.75f, h * 0.68f, p)
        } else {
            canvas.drawRoundRect(w * 0.25f, 1f, w * 0.75f, h - 1f, w * 0.25f, w * 0.25f, p)
            canvas.drawLine(w * 0.5f, 1f, w * 0.5f, h * 0.4f, p)
        }
    }
}

/** Joystick desenhado na tela. */
class JoyView(context: Context, private val color: Int, var selected: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2
        val cy = height / 2f
        val r = w / 2 - 4f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#55000000")
        canvas.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = if (selected) Color.WHITE else color
        canvas.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL
        p.color = color
        canvas.drawCircle(cx, cy, r * 0.32f, p)
        p.color = Color.WHITE
        canvas.drawCircle(cx, cy - r * 0.72f, 4f, p)
        canvas.drawCircle(cx, cy + r * 0.72f, 4f, p)
        canvas.drawCircle(cx - r * 0.72f, cy, 4f, p)
        canvas.drawCircle(cx + r * 0.72f, cy, 4f, p)
    }
}

/**
 * O mapeador. Ele é um serviço de acessibilidade: recebe as teclas do teclado,
 * faz os toques na tela do jogo e desenha a coroa, o menu e as teclas por cima.
 *
 * Três estados separados: saved (oficial, usado no jogo), work (edição temporária)
 * e o rascunho gravado em disco. Cancelar nunca mexe em saved.
 */
class MapperService : AccessibilityService() {

    companion object {
        var instance: MapperService? = null
        var enabled by mutableStateOf(false)
    }

    private lateinit var wm: WindowManager
    private lateinit var layerLp: WindowManager.LayoutParams
    private lateinit var fabLp: WindowManager.LayoutParams
    private lateinit var barLp: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())
    private var homePkg = ""
    private var gamePkg: String? = null
    private var devicesOn = false
    private var saved = Keymap()
    private var work: Keymap? = null
    private var selKey: KeyDef? = null
    private var selJoy = false
    private var typing = false
    private var layer: FrameLayout? = null
    private var fab: View? = null
    private var menu: View? = null
    private var bar: LinearLayout? = null
    private var batteryTv: TextView? = null
    private var mouseIcon: DeviceIcon? = null
    private var kbIcon: DeviceIcon? = null
    private var editBar: View? = null
    private var appPanel: View? = null
    private var dialog: View? = null
    private val holds = LinkedHashMap<Int, Hold>()
    private val joyDown = HashSet<Int>()
    private var dispatching = false

    // ------------------------------------------------------------ ciclo de vida

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        enabled = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        homePkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName ?: ""
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopGameMode()
        instance = null
        enabled = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.postDelayed({ render() }, 300)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        if (gamePkg != null && ev.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            homePkg.isNotEmpty() && ev.packageName?.toString() == homePkg
        ) stopGameMode()
    }

    // ------------------------------------------------------------ modo jogo

    fun startGameMode(pkg: String) {
        stopGameMode()
        gamePkg = pkg
        saved = LayoutStore.loadSaved(this, pkg)
        work = null
        typing = false
        selKey = null
        selJoy = false
        Devices.start(applicationContext)
        devicesOn = true
        buildLayer()
        buildFab()
        buildBar()
        render()
        ui.post(tick)
    }

    fun stopGameMode() {
        if (!::wm.isInitialized) return
        ui.removeCallbacks(tick)
        holds.clear()
        joyDown.clear()
        for (v in listOf(menu, dialog, appPanel, editBar, bar, fab, layer)) {
            if (v != null) {
                try { wm.removeView(v) } catch (e: Exception) { }
            }
        }
        menu = null; dialog = null; appPanel = null; editBar = null
        bar = null; fab = null; layer = null
        batteryTv = null; mouseIcon = null; kbIcon = null
        work = null
        selKey = null
        selJoy = false
        gamePkg = null
        if (devicesOn) {
            Devices.stop()
            devicesOn = false
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (gamePkg == null) return
            Devices.refresh()
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
            batteryTv?.text = if (pct >= 0) "Bat. $pct%" else "Bat. --"
            mouseIcon?.color = colorOf(Devices.mouse)
            kbIcon?.color = colorOf(Devices.keyboard)
            ui.postDelayed(this, 1000)
        }
    }

    // ------------------------------------------------------------ teclado -> toque

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (gamePkg == null) return false
        val dev = event.device
        if (dev != null && !dev.isVirtual && dev.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC) {
            Devices.markKeyboardSeen()
        }
        val code = event.keyCode
        if (code in setOf(
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_APP_SWITCH,
                KeyEvent.KEYCODE_POWER, KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_UNKNOWN
            )
        ) return false

        // editando: a próxima tecla apertada vincula na bolinha selecionada
        if (work != null) {
            val sel = selKey ?: return false
            if (event.action == KeyEvent.ACTION_DOWN) {
                sel.code = code
                sel.label = labelFor(code)
                changed()
                render()
            }
            return true
        }
        if (typing) return false

        // jogando: sempre usa o layout SALVO, esteja ele visível ou escondido
        val lay = saved
        val joy = lay.joy
        if (joy != null && (code == joy.up || code == joy.left || code == joy.down || code == joy.right)) {
            if (event.action == KeyEvent.ACTION_DOWN) joyDown.add(code)
            else if (event.action == KeyEvent.ACTION_UP) joyDown.remove(code)
            updateJoy(joy)
            return true
        }
        val k = lay.keys.firstOrNull { it.code == code } ?: return false
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0 && !holds.containsKey(code)) press(k)
        } else if (event.action == KeyEvent.ACTION_UP) {
            release(code)
        }
        return true
    }

    private fun labelFor(code: Int): String = when (code) {
        KeyEvent.KEYCODE_SPACE -> "Esp"
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "Shift"
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "Ctrl"
        KeyEvent.KEYCODE_TAB -> "Tab"
        KeyEvent.KEYCODE_ENTER -> "Enter"
        else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").take(4)
    }

    private fun press(k: KeyDef) {
        val (w, h) = screen()
        holds[k.code] = Hold(k.x * w, k.y * h)
        pump()
    }

    private fun release(code: Int) {
        val h = holds[code] ?: return
        h.release = true
        pump()
    }

    /** Joystick digital: segura um toque no centro e leva até a borda na direção das teclas. */
    private fun updateJoy(joy: JoyDef) {
        val (w, h) = screen()
        val cx = joy.x * w
        val cy = joy.y * h
        var dx = 0f
        var dy = 0f
        if (joy.right in joyDown) dx += 1f
        if (joy.left in joyDown) dx -= 1f
        if (joy.down in joyDown) dy += 1f
        if (joy.up in joyDown) dy -= 1f
        val cur = holds[JOY_ID]
        if (dx == 0f && dy == 0f) {
            if (cur != null) {
                cur.release = true
                pump()
            }
            return
        }
        val len = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        val reach = dp(joy.radius) * 0.8f
        val tx = cx + dx / len * reach
        val ty = cy + dy / len * reach
        if (cur == null) {
            val n = Hold(cx, cy)
            n.joy = true
            n.tx = tx
            n.ty = ty
            holds[JOY_ID] = n
        } else {
            cur.release = false
            cur.cx = cx
            cur.cy = cy
            cur.tx = tx
            cur.ty = ty
        }
        pump()
    }

    /** Mantém os toques segurados: cada envio continua o anterior até a tecla ser solta. */
    private fun pump() {
        if (dispatching || holds.isEmpty()) return
        val builder = GestureDescription.Builder()
        val ended = ArrayList<Int>()
        for ((id, h) in holds) {
            val path = Path()
            path.moveTo(h.x, h.y)
            val dur: Long
            if (h.joy) {
                val ex = if (h.release) h.cx else h.tx
                val ey = if (h.release) h.cy else h.ty
                if (ex != h.x || ey != h.y) path.lineTo(ex, ey)
                h.x = ex
                h.y = ey
                dur = 40L
            } else {
                dur = 10L
            }
            val cont = !h.release
            val prev = h.stroke
            val s = if (prev != null) prev.continueStroke(path, 0L, dur, cont)
            else GestureDescription.StrokeDescription(path, 0L, dur, cont)
            h.stroke = s
            builder.addStroke(s)
            if (h.release) ended.add(id)
        }
        for (c in ended) holds.remove(c)
        dispatching = true
        val ok = dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                dispatching = false
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                dispatching = false
                holds.clear()
            }
        }, null)
        if (!ok) {
            dispatching = false
            holds.clear()
        }
    }

    // ------------------------------------------------------------ ajudantes de tela

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun pill(color: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun circle(sel: Boolean, color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (sel) color else Color.parseColor("#B3000000"))
        setStroke(dp(2), if (sel) Color.WHITE else color)
    }

    private fun btn(label: String, hot: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(9), dp(12), dp(9))
        background = pill(
            if (hot) NEON else Color.parseColor("#201215"),
            if (hot) NEON else Color.parseColor("#3D1A20"), 12
        )
        setOnClickListener { onClick() }
    }

    private fun margins(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(WRAP, WRAP).apply {
            marginStart = dp(4)
            marginEnd = dp(4)
        }

    private fun safeAdd(v: View, lp: WindowManager.LayoutParams) {
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível mostrar os controles sobre o jogo", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeWin(v: View?) {
        if (v != null) {
            try { wm.removeView(v) } catch (e: Exception) { }
        }
    }

    private fun makeDraggable(v: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)?, onDone: () -> Unit) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (moved || Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                        if (!moved) closeMenu()
                        moved = true
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onDone() else onTap?.invoke()
                }
            }
            true
        }
    }

    private fun uiPrefs() = getSharedPreferences("ui", Context.MODE_PRIVATE)

    // ------------------------------------------------------------ janelas por cima do jogo

    private fun buildLayer() {
        val l = FrameLayout(this)
        layerLp = lpOf(MATCH, MATCH, NF or NT or LS)
        safeAdd(l, layerLp)
        layer = l
    }

    private fun buildBar() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = pill(Color.parseColor("#CC0A0607"), NEON, 12)
        }
        val b = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
        }
        val m = DeviceIcon(this, false)
        val k = DeviceIcon(this, true)
        row.addView(b)
        row.addView(m, LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginStart = dp(10) })
        row.addView(k, LinearLayout.LayoutParams(dp(18), dp(16)).apply { marginStart = dp(8) })
        val prefs = uiPrefs()
        barLp = lpOf(WRAP, WRAP, NF or NM or LS)
        barLp.x = prefs.getInt("bar_x", dp(8))
        barLp.y = prefs.getInt("bar_y", dp(4))
        makeDraggable(row, barLp, null) {
            uiPrefs().edit().putInt("bar_x", barLp.x).putInt("bar_y", barLp.y).apply()
        }
        safeAdd(row, barLp)
        bar = row
        batteryTv = b
        mouseIcon = m
        kbIcon = k
        m.color = colorOf(Devices.mouse)
        k.color = colorOf(Devices.keyboard)
        applyBarMode()
    }

    private fun barModeName() = listOf("visível", "discreta", "transparente", "oculta")[uiPrefs().getInt("bar_mode", 0)]

    private fun applyBarMode() {
        val r = bar ?: return
        if (work != null) {
            r.visibility = View.GONE
            return
        }
        when (uiPrefs().getInt("bar_mode", 0)) {
            0 -> { r.visibility = View.VISIBLE; r.alpha = 1f }
            1 -> { r.visibility = View.VISIBLE; r.alpha = 0.55f }
            2 -> { r.visibility = View.VISIBLE; r.alpha = 0.25f }
            else -> r.visibility = View.GONE
        }
    }

    private fun cycleBar() {
        val next = (uiPrefs().getInt("bar_mode", 0) + 1) % 4
        uiPrefs().edit().putInt("bar_mode", next).apply()
        applyBarMode()
    }

    private fun buildFab() {
        val v = CrownView(this)
        fabLp = lpOf(dp(48), dp(48), NF or NM or LS)
        fabLp.x = dp(12)
        fabLp.y = dp(80)
        makeDraggable(v, fabLp, { toggleMenu() }) { }
        safeAdd(v, fabLp)
        fab = v
    }

    private fun closeMenu() {
        removeWin(menu)
        menu = null
    }

    private fun toggleMenu() {
        if (menu != null) {
            closeMenu()
            return
        }
        if (work != null) {
            Toast.makeText(this, "Termine a edição: Salvar ou Cancelar", Toast.LENGTH_SHORT).show()
            return
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = pill(DARK, NEON, 14)
        }
        fun item(label: String, hot: Boolean = false, a: () -> Unit) {
            col.addView(btn(label, hot) { a() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })
        }
        item("Editar keymap") { closeMenu(); enterEdit() }
        item(if (saved.mode == 3) "Mostrar teclas" else "Esconder teclas") {
            toggleVisibility()
            closeMenu()
        }
        item("Barra: ${barModeName()}") { cycleBar(); closeMenu() }
        item(if (typing) "Voltar a jogar" else "Digitar no teclado") {
            typing = !typing
            closeMenu()
            Toast.makeText(
                this,
                if (typing) "Mapeamento pausado: o teclado digita normal" else "Mapeamento ligado",
                Toast.LENGTH_SHORT
            ).show()
        }
        item("Sair do modo jogo", true) { stopGameMode() }
        val p = lpOf(WRAP, WRAP, NF or NM or LS)
        p.x = fabLp.x + dp(56)
        p.y = fabLp.y
        safeAdd(col, p)
        menu = col
    }

    /** Esconde ou mostra só o desenho. Os comandos continuam funcionando do mesmo jeito. */
    private fun toggleVisibility() {
        val pkg = gamePkg ?: return
        if (saved.mode == 3) {
            saved.mode = 0
            if (saved.opacity < 20) saved.opacity = 90
        } else {
            saved.mode = 3
        }
        LayoutStore.save(this, pkg, saved)
        render()
    }

    // ------------------------------------------------------------ desenho das teclas

    private fun render() {
        val l = layer ?: return
        for (i in l.childCount - 1 downTo 0) {
            val t = l.getChildAt(i).tag
            if (t is KeyDef || t is JoyDef) l.removeViewAt(i)
        }
        val lay = work ?: saved
        val editing = work != null
        if (!editing && lay.mode == 3) return
        val w = if (l.width > 0) l.width else screen().first
        val h = if (l.height > 0) l.height else screen().second
        val a = if (editing) maxOf(lay.opacity / 100f, 0.35f) else lay.opacity / 100f
        val color = Keymap.COLORS[lay.color.coerceIn(0, Keymap.COLORS.size - 1)]
        val joy = lay.joy
        if (joy != null) {
            val js = dp(joy.radius * 2)
            val jv = JoyView(this, color, selJoy && editing)
            jv.tag = joy
            jv.alpha = a
            jv.layoutParams = FrameLayout.LayoutParams(js, js).apply {
                leftMargin = (joy.x * w - js / 2).toInt()
                topMargin = (joy.y * h - js / 2).toInt()
            }
            if (editing) jv.setOnTouchListener(dragJoy(joy))
            l.addView(jv)
        }
        val s = dp(lay.keySize)
        for (k in lay.keys) {
            val tv = TextView(this)
            tv.tag = k
            tv.text = k.label
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.background = circle(k === selKey && editing, color)
            tv.alpha = a
            tv.layoutParams = FrameLayout.LayoutParams(s, s).apply {
                leftMargin = (k.x * w - s / 2).toInt()
                topMargin = (k.y * h - s / 2).toInt()
            }
            if (editing) tv.setOnTouchListener(dragKey(k))
            l.addView(tv)
        }
    }

    private fun paintSelection() {
        val l = layer ?: return
        val lay = work ?: return
        val color = Keymap.COLORS[lay.color.coerceIn(0, Keymap.COLORS.size - 1)]
        for (i in 0 until l.childCount) {
            val c = l.getChildAt(i)
            val t = c.tag
            if (t is KeyDef) {
                c.background = circle(t === selKey, color)
            } else if (t is JoyDef && c is JoyView) {
                c.selected = selJoy
                c.invalidate()
            }
        }
    }

    private fun moveView(v: View, e: MotionEvent, size: Int, maxX: Float, set: (Float, Float) -> Unit) {
        val l = layer ?: return
        val w = if (l.width > 0) l.width else screen().first
        val h = if (l.height > 0) l.height else screen().second
        val fx = (e.rawX / w).coerceIn(0.02f, maxX)
        val fy = (e.rawY / h).coerceIn(0.02f, 0.98f)
        set(fx, fy)
        val p = v.layoutParams as FrameLayout.LayoutParams
        p.leftMargin = (fx * w - size / 2).toInt()
        p.topMargin = (fy * h - size / 2).toInt()
        v.layoutParams = p
    }

    private fun dragKey(k: KeyDef) = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selKey = k
                selJoy = false
                paintSelection()
            }
            MotionEvent.ACTION_MOVE -> moveView(v, e, dp((work ?: saved).keySize), 0.98f) { fx, fy ->
                k.x = fx
                k.y = fy
            }
            MotionEvent.ACTION_UP -> changed()
        }
        true
    }

    /** O joystick fica sempre na região esquerda (até 55% da largura). */
    private fun dragJoy(j: JoyDef) = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selJoy = true
                selKey = null
                paintSelection()
            }
            MotionEvent.ACTION_MOVE -> moveView(v, e, dp(j.radius * 2), 0.55f) { fx, fy ->
                j.x = fx
                j.y = fy
            }
            MotionEvent.ACTION_UP -> changed()
        }
        true
    }

    // ------------------------------------------------------------ edição

    /** Grava o rascunho de recuperação. Não toca no layout salvo. */
    private fun changed() {
        val w = work ?: return
        val pkg = gamePkg ?: return
        LayoutStore.saveDraft(this, pkg, w)
    }

    private fun enterEdit() {
        val pkg = gamePkg ?: return
        val draft = LayoutStore.draft(this, pkg)
        if (draft != null) {
            showDialog(
                "Rascunho encontrado",
                "Uma edição anterior não foi salva. Quer continuar de onde parou?",
                listOf(
                    "Restaurar rascunho" to { beginEdit(draft) },
                    "Começar do salvo" to {
                        LayoutStore.clearDraft(this, pkg)
                        beginEdit(saved.copy())
                    },
                    "Fechar" to { }
                )
            )
        } else {
            beginEdit(saved.copy())
        }
    }

    private fun beginEdit(k: Keymap) {
        val l = layer ?: return
        work = k
        selKey = null
        selJoy = false
        layerLp.flags = NF or LS
        l.setBackgroundColor(Color.parseColor("#99000000"))
        wm.updateViewLayout(l, layerLp)
        applyBarMode()
        buildEditUi()
        render()
    }

    private fun endEdit() {
        work = null
        selKey = null
        selJoy = false
        removeWin(editBar)
        editBar = null
        removeWin(appPanel)
        appPanel = null
        removeWin(dialog)
        dialog = null
        val l = layer
        if (l != null) {
            l.setBackgroundColor(Color.TRANSPARENT)
            layerLp.flags = NF or NT or LS
            wm.updateViewLayout(l, layerLp)
        }
        applyBarMode()
        render()
    }

    private fun buildEditUi() {
        val sw = screen().first
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = pill(DARK, NEON, 14)
        }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tool(label: String, a: () -> Unit) {
            tools.addView(btn(label, false, a), margins())
        }
        tool("+ Tecla") { addKey() }
        tool("+ Joystick") { addJoy() }
        tool("Modelo") { applyTemplate() }
        tool("Excluir") { deleteSelected() }
        tool("Aparência") { toggleAppearance() }
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(tools)
        row.addView(scroll, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(btn("CANCELAR") { onCancel() }, margins())
        row.addView(btn("SALVAR KEYMAP", true) { onSave() }, margins())
        val hint = TextView(this).apply {
            text = "Toque numa bolinha e aperte a tecla do teclado para vincular. Arraste para mover."
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(row)
        col.addView(hint)
        val p = lpOf((sw * 0.94f).toInt(), WRAP, NF or NM or LS).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(6)
        }
        safeAdd(col, p)
        editBar = col
    }

    private fun addKey() {
        val w = work ?: return
        val k = KeyDef(0, "?", 0.5f, 0.5f)
        w.keys.add(k)
        selKey = k
        selJoy = false
        changed()
        render()
    }

    private fun newJoy() = JoyDef(
        0.16f, 0.70f, 60,
        KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D
    )

    private fun addJoy() {
        val w = work ?: return
        if (w.joy != null) {
            Toast.makeText(this, "Já existe um joystick", Toast.LENGTH_SHORT).show()
            return
        }
        w.joy = newJoy()
        selJoy = true
        selKey = null
        changed()
        render()
        Toast.makeText(this, "Joystick nas teclas W A S D (8 direções, digital)", Toast.LENGTH_LONG).show()
    }

    private fun deleteSelected() {
        val w = work ?: return
        val sk = selKey
        if (sk != null) {
            w.keys.remove(sk)
            selKey = null
        } else if (selJoy) {
            w.joy = null
            selJoy = false
        } else {
            Toast.makeText(this, "Toque numa bolinha ou no joystick primeiro", Toast.LENGTH_SHORT).show()
            return
        }
        changed()
        render()
    }

    private fun applyTemplate() {
        val w = work ?: return
        w.keys.clear()
        w.keys.add(KeyDef(KeyEvent.KEYCODE_F, "F", 0.80f, 0.72f))
        w.keys.add(KeyDef(KeyEvent.KEYCODE_R, "R", 0.92f, 0.36f))
        w.keys.add(KeyDef(KeyEvent.KEYCODE_E, "E", 0.86f, 0.86f))
        w.keys.add(KeyDef(KeyEvent.KEYCODE_SPACE, "Esp", 0.90f, 0.56f))
        if (w.joy == null) w.joy = newJoy()
        selKey = null
        selJoy = false
        changed()
        render()
    }

    private fun onSave() {
        val w = work ?: return
        val pkg = gamePkg ?: return
        w.keys.removeAll { it.code == 0 }
        LayoutStore.save(this, pkg, w)
        LayoutStore.clearDraft(this, pkg)
        saved = w
        holds.clear()
        joyDown.clear()
        endEdit()
        Toast.makeText(this, "Keymap salvo", Toast.LENGTH_SHORT).show()
    }

    private fun onCancel() {
        val w = work ?: return
        if (w.toJson() == saved.toJson()) {
            discardEdit()
            return
        }
        showDialog(
            "Alterações não salvas",
            "O layout salvo continua intacto. O que você quer fazer?",
            listOf(
                "Salvar e sair" to { onSave() },
                "Descartar alterações" to { discardEdit() },
                "Continuar editando" to { }
            )
        )
    }

    private fun discardEdit() {
        val pkg = gamePkg ?: return
        LayoutStore.clearDraft(this, pkg)
        endEdit()
    }

    private fun showDialog(title: String, msg: String, opts: List<Pair<String, () -> Unit>>) {
        removeWin(dialog)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = pill(DARK, NEON, 14)
        }
        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        t.typeface = Typeface.DEFAULT_BOLD
        col.addView(t)
        val m = TextView(this)
        m.text = msg
        m.setTextColor(Color.parseColor("#C9BCBE"))
        m.textSize = 13f
        m.setPadding(0, dp(6), 0, dp(8))
        col.addView(m)
        for ((label, action) in opts) {
            col.addView(btn(label, label.startsWith("Salvar") || label.startsWith("Restaurar")) {
                removeWin(dialog)
                dialog = null
                action()
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        }
        val p = lpOf(dp(300), WRAP, NF or NM or LS)
        p.gravity = Gravity.CENTER
        safeAdd(col, p)
        dialog = col
    }

    // ------------------------------------------------------------ aparência (tempo real)

    private fun seekRow(label: String, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = "$label: $value"
        t.setTextColor(Color.WHITE)
        t.textSize = 12f
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = value - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val v = p + min
                    t.text = "$label: $v"
                    onChange(v)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                changed()
            }
        })
        col.addView(t)
        col.addView(sb, LinearLayout.LayoutParams(dp(240), WRAP))
        return col
    }

    private fun toggleAppearance() {
        if (appPanel != null) {
            removeWin(appPanel)
            appPanel = null
            return
        }
        openAppearance()
    }

    private fun reopenAppearance() {
        removeWin(appPanel)
        appPanel = null
        openAppearance()
    }

    private fun openAppearance() {
        val w = work ?: return
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = pill(DARK, NEON, 14)
        }
        val title = TextView(this)
        title.text = "Aparência das teclas"
        title.setTextColor(Color.WHITE)
        title.textSize = 13f
        title.typeface = Typeface.DEFAULT_BOLD
        col.addView(title)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("Visível", "Discreto", "Transparente", "Oculto")
        val presets = intArrayOf(90, 45, 20, -1)
        names.forEachIndexed { i, n ->
            modes.addView(btn(n, w.mode == i) {
                w.mode = i
                if (presets[i] >= 0) w.opacity = presets[i]
                changed()
                render()
                reopenAppearance()
            }, margins())
        }
        col.addView(modes, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        col.addView(seekRow("Opacidade (%)", 0, 100, w.opacity) { v ->
            w.opacity = v
            render()
        })
        col.addView(seekRow("Tamanho das teclas", 28, 72, w.keySize) { v ->
            w.keySize = v
            render()
        })
        val joy = w.joy
        if (joy != null) {
            col.addView(seekRow("Tamanho do joystick", 30, 90, joy.radius) { v ->
                joy.radius = v
                render()
            })
        }
        val sws = LinearLayout(this)
        sws.orientation = LinearLayout.HORIZONTAL
        Keymap.COLORS.forEachIndexed { i, c ->
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(dp(2), if (w.color == i) Color.WHITE else Color.TRANSPARENT)
            }
            dot.setOnClickListener {
                w.color = i
                changed()
                render()
                reopenAppearance()
            }
            sws.addView(dot, LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                marginEnd = dp(8)
                topMargin = dp(8)
            })
        }
        col.addView(sws)
        val p = lpOf(WRAP, WRAP, NF or NM or LS)
        p.x = dp(12)
        p.y = dp(72)
        safeAdd(col, p)
        appPanel = col
    }
}
