package br.com.santosmousegg

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

private val NEON = Color.parseColor("#E5202E")
private val DARK = Color.parseColor("#F0150D0F")
private val GREEN = Color.parseColor("#32D27A")
private val AMBER = Color.parseColor("#FFC107")
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val NF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
private const val NT = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
private const val NM = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
private const val LS = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
private const val JOY_ID = -1000
private const val CAM_ID = -2000

private fun lpOf(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
    w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
).apply { gravity = Gravity.TOP or Gravity.START }

private fun colorOf(s: DevState) = when (s) {
    DevState.OK -> GREEN
    DevState.LIMITED -> AMBER
    DevState.OFF -> NEON
}

/** Códigos dos botões do mouse: -1 esquerdo, -2 direito, -3 rodinha, -4 e -5 laterais. */
private fun mouseCodeFor(buttonState: Int): Int = when {
    (buttonState and MotionEvent.BUTTON_PRIMARY) != 0 -> -1
    (buttonState and MotionEvent.BUTTON_SECONDARY) != 0 -> -2
    (buttonState and MotionEvent.BUTTON_TERTIARY) != 0 -> -3
    (buttonState and MotionEvent.BUTTON_BACK) != 0 -> -4
    (buttonState and MotionEvent.BUTTON_FORWARD) != 0 -> -5
    else -> 0
}

private fun labelFor(code: Int): String = when (code) {
    -1 -> "Esq"
    -2 -> "Dir"
    -3 -> "Rod"
    -4 -> "Lat1"
    -5 -> "Lat2"
    KeyEvent.KEYCODE_SPACE -> "Esp"
    KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "Shift"
    KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "Ctrl"
    KeyEvent.KEYCODE_TAB -> "Tab"
    KeyEvent.KEYCODE_ENTER -> "Enter"
    else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").take(4)
}

/** Um toque que está sendo segurado no jogo (tecla, botão do mouse, joystick ou câmera). */
class Hold(var x: Float, var y: Float) {
    var tx = x
    var ty = y
    var cx = x
    var cy = y
    var joy = false
    var cam = false
    var mouse = false
    var watch = false
    var seen = 0L
    var stroke: GestureDescription.StrokeDescription? = null
    var release = false
}

/** Botão redondo com a coroa. */
class CrownView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#E60A0607")
        canvas.drawCircle(w / 2, h / 2, w / 2 - 3f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = NEON
        canvas.drawCircle(w / 2, h / 2, w / 2 - 3f, paint)
        val path = Path().apply {
            moveTo(0.28f * w, 0.68f * h); lineTo(0.20f * w, 0.34f * h); lineTo(0.36f * w, 0.46f * h)
            lineTo(0.50f * w, 0.26f * h); lineTo(0.64f * w, 0.46f * h); lineTo(0.80f * w, 0.34f * h)
            lineTo(0.72f * w, 0.68f * h); close()
        }
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
    }
}

/** Ícone de mouse ou teclado que muda de cor conforme o estado. */
class DeviceIcon(context: Context, private val keyboard: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var color: Int = Color.GRAY
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f
        p.color = color
        if (keyboard) {
            canvas.drawRoundRect(1f, h * 0.25f, w - 1f, h * 0.8f, 4f, 4f, p)
            p.style = Paint.Style.FILL
            for (i in 0..2) canvas.drawCircle(w * (0.25f + 0.25f * i), h * 0.45f, 1.6f, p)
            canvas.drawRect(w * 0.25f, h * 0.62f, w * 0.75f, h * 0.68f, p)
        } else {
            canvas.drawRoundRect(w * 0.25f, 1f, w * 0.75f, h - 1f, w * 0.25f, w * 0.25f, p)
            canvas.drawLine(w * 0.5f, 1f, w * 0.5f, h * 0.4f, p)
        }
    }
}

/** Joystick desenhado na tela. */
class JoyView(context: Context, private val color: Int, var picked: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2
        val cy = height / 2f
        val r = w / 2 - 4f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#55000000")
        canvas.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = if (picked) Color.WHITE else color
        canvas.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL
        p.color = color
        canvas.drawCircle(cx, cy, r * 0.32f, p)
        p.color = Color.WHITE
        canvas.drawCircle(cx, cy - r * 0.72f, 4f, p)
        canvas.drawCircle(cx, cy + r * 0.72f, 4f, p)
        canvas.drawCircle(cx - r * 0.72f, cy, 4f, p)
        canvas.drawCircle(cx + r * 0.72f, cy, 4f, p)
    }
}

/** A bolinha única do controle de câmera. */
class CamView(context: Context, private val color: Int, var picked: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2
        val cy = height / 2f
        val r = w / 2 - 4f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#33000000")
        canvas.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = if (picked) Color.WHITE else color
        canvas.drawCircle(cx, cy, r, p)
        p.strokeWidth = 3f
        p.color = color
        canvas.drawLine(cx - r * 0.5f, cy, cx + r * 0.5f, cy, p)
        canvas.drawLine(cx, cy - r * 0.5f, cx, cy + r * 0.5f, p)
        p.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, 5f, p)
    }
}

/** Janela invisível que recebe o mouse capturado (movimento relativo e botões). */
class CaptureView(context: Context, private val owner: MapperService) : View(context) {
    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onPointerCaptureChange(hasCapture: Boolean) {
        super.onPointerCaptureChange(hasCapture)
        owner.captureChanged(hasCapture)
    }

    override fun onCapturedPointerEvent(event: MotionEvent): Boolean {
        owner.onCaptured(event)
        return true
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        owner.focusChanged(hasWindowFocus, this)
    }
}

/**
 * O mapeador. Ele é um serviço de acessibilidade: recebe as teclas do teclado, captura o mouse,
 * faz os toques na tela do jogo e desenha a coroa, o menu e as teclas por cima.
 *
 * Três estados separados: saved (oficial, usado no jogo), work (edição temporária)
 * e o rascunho gravado em disco. Cancelar nunca mexe em saved.
 */
class MapperService : AccessibilityService() {

    companion object {
        var instance: MapperService? = null
        var enabled by mutableStateOf(false)
    }

    private lateinit var wm: WindowManager
    private lateinit var layerLp: WindowManager.LayoutParams
    private lateinit var capLp: WindowManager.LayoutParams
    private lateinit var fabLp: WindowManager.LayoutParams
    private lateinit var barLp: WindowManager.LayoutParams
    private lateinit var editLp: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())
    private var homePkg = ""
    private var gamePkg: String? = null
    private var devicesOn = false
    private var saved = Keymap()
    private var work: Keymap? = null
    private var selKey: KeyDef? = null
    private var selJoy = false
    private var selCam = false
    private var typing = false
    private var manualFree = false
    private var fastActive = false
    private var wantCapture = false
    private var captured = false
    private var awaitBind = 0
    private var waitMouse = false
    private var editExpanded = true
    private var capWarn = 0
    private var layer: FrameLayout? = null
    private var capView: CaptureView? = null
    private var fab: View? = null
    private var menu: View? = null
    private var bar: LinearLayout? = null
    private var batteryTv: TextView? = null
    private var mouseIcon: DeviceIcon? = null
    private var kbIcon: DeviceIcon? = null
    private var editWin: View? = null
    private var appPanel: View? = null
    private var sensPanel: View? = null
    private var infoTv: TextView? = null
    private var dialog: View? = null
    private val holds = LinkedHashMap<Int, Hold>()
    private val joyDown = HashSet<Int>()
    private val joySeen = HashMap<Int, Long>()
    private var dispatching = false
    private var lastDispatch = 0L
    private var lastButtons = 0
    private var camLast = 0L
    private var offX = 0f
    private var offY = 0f
    private var pendX = 0f
    private var pendY = 0f
    private var lastDx = 0f
    private var lastDy = 0f

    // ------------------------------------------------------------ ciclo de vida

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        enabled = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        homePkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName ?: ""
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopGameMode()
        instance = null
        enabled = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {
        releaseAll()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.postDelayed({ render() }, 300)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        if (gamePkg == null || ev.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = ev.packageName?.toString() ?: return
        if (pkg == packageName) return
        // mudou a janela em foco: solta tudo para nada ficar preso
        releaseAll()
        if (homePkg.isNotEmpty() && pkg == homePkg) stopGameMode()
    }

    // ------------------------------------------------------------ modo jogo

    fun startGameMode(pkg: String) {
        stopGameMode()
        gamePkg = pkg
        saved = LayoutStore.loadSaved(this, pkg)
        work = null
        typing = false
        manualFree = false
        fastActive = false
        awaitBind = 0
        waitMouse = false
        selKey = null
        selJoy = false
        selCam = false
        capWarn = 0
        Devices.start(applicationContext)
        devicesOn = true
        buildLayer()
        buildCapture()
        buildFab()
        buildBar()
        render()
        applyCapture()
        ui.post(tick)
        ui.post(guard)
    }

    fun stopGameMode() {
        if (!::wm.isInitialized) return
        ui.removeCallbacks(tick)
        ui.removeCallbacks(guard)
        ui.removeCallbacks(recapture)
        releaseAll()
        wantCapture = false
        for (v in listOf(menu, dialog, appPanel, sensPanel, editWin, bar, fab, capView, layer)) {
            if (v != null) {
                try { wm.removeView(v) } catch (e: Exception) { }
            }
        }
        menu = null; dialog = null; appPanel = null; sensPanel = null; editWin = null
        bar = null; fab = null; capView = null; layer = null
        batteryTv = null; mouseIcon = null; kbIcon = null; infoTv = null
        work = null
        selKey = null
        selJoy = false
        selCam = false
        captured = false
        gamePkg = null
        if (devicesOn) {
            Devices.stop()
            devicesOn = false
        }
    }

    private val recapture = Runnable {
        fastActive = false
        applyCapture()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (gamePkg == null) return
            Devices.refresh()
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
            var txt = if (pct >= 0) "Bat. $pct%" else "Bat. --"
            if (needCapture()) txt += if (captured) " • Captura ON" else " • Captura OFF"
            batteryTv?.text = txt
            mouseIcon?.color = colorOf(Devices.mouse)
            kbIcon?.color = colorOf(Devices.keyboard)
            if (Devices.keyboard == DevState.OFF) releaseAll()
            ui.postDelayed(this, 1000)
        }
    }

    /** Vigia: se algum "solta" se perder, o comando é liberado mesmo assim. */
    private val guard = object : Runnable {
        override fun run() {
            if (gamePkg == null) return
            val now = SystemClock.uptimeMillis()
            if (dispatching && now - lastDispatch > 500) dispatching = false
            for ((_, h) in holds) {
                if (h.watch && !h.release && now - h.seen > 1200) h.release = true
            }
            var changed = false
            for (c in ArrayList(joyDown)) {
                if (now - (joySeen[c] ?: 0L) > 1200) {
                    joyDown.remove(c)
                    changed = true
                }
            }
            val joy = saved.joy
            if (changed && joy != null) updateJoy(joy)
            if (holds.isNotEmpty()) pump()
            ui.postDelayed(this, 100)
        }
    }

    /** Solta todos os comandos que estiverem ativos. */
    private fun releaseAll() {
        joyDown.clear()
        joySeen.clear()
        lastButtons = 0
        offX = 0f; offY = 0f; pendX = 0f; pendY = 0f
        for ((_, h) in holds) h.release = true
        if (holds.isNotEmpty()) pump()
    }

    private fun releaseCameraAndMouse() {
        for ((_, h) in holds) {
            if (h.cam || h.mouse) h.release = true
        }
        lastButtons = 0
        offX = 0f; offY = 0f; pendX = 0f; pendY = 0f
        if (holds.isNotEmpty()) pump()
    }

    // ------------------------------------------------------------ teclado -> toque

    private fun needCapture(): Boolean {
        val k = saved
        return k.cam != null || k.keys.any { it.code in -5..-1 }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (gamePkg == null) return false
        val dev = event.device
        if (dev != null && !dev.isVirtual && dev.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC) {
            Devices.markKeyboardSeen()
        }
        val code = event.keyCode
        if (code in setOf(
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_APP_SWITCH,
                KeyEvent.KEYCODE_POWER, KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_UNKNOWN
            )
        ) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        val up = event.action == KeyEvent.ACTION_UP
        val now = SystemClock.uptimeMillis()

        // aguardando a escolha de uma das teclas de alternância
        if (awaitBind != 0) {
            if (down) {
                val t = work ?: saved
                if (awaitBind == 1) t.fastKey = code else t.manualKey = code
                awaitBind = 0
                persist()
                reopenSens()
                Toast.makeText(this, "Tecla ${labelFor(code)} definida", Toast.LENGTH_SHORT).show()
            }
            return true
        }

        // editando: a próxima tecla apertada vincula na bolinha selecionada
        if (work != null) {
            val sel = selKey ?: return false
            if (down) {
                sel.code = code
                sel.label = labelFor(code)
                waitMouse = false
                changed()
                render()
            }
            return true
        }
        if (typing) return false

        val km = saved
        if (km.fastKey != 0 && code == km.fastKey && needCapture()) {
            if (down && event.repeatCount == 0) fastToggle()
            return true
        }
        if (km.manualKey != 0 && code == km.manualKey && needCapture()) {
            if (down && event.repeatCount == 0) manualToggle()
            return true
        }

        val joy = km.joy
        if (joy != null && (code == joy.up || code == joy.left || code == joy.down || code == joy.right)) {
            if (down) {
                joySeen[code] = now
                if (event.repeatCount == 0) {
                    joyDown.add(code)
                    updateJoy(joy)
                }
            } else if (up) {
                joyDown.remove(code)
                joySeen.remove(code)
                updateJoy(joy)
            }
            return true
        }
        val k = km.keys.firstOrNull { it.code == code } ?: return false
        if (down) {
            if (event.repeatCount == 0) {
                if (!holds.containsKey(code)) press(k, true)
            } else {
                holds[code]?.seen = now
            }
        } else if (up) {
            release(code)
        }
        return true
    }

    private fun press(k: KeyDef, isKey: Boolean) {
        val (w, h) = screen()
        val hold = Hold(k.x * w, k.y * h)
        hold.watch = isKey
        hold.mouse = !isKey
        hold.seen = SystemClock.uptimeMillis()
        holds[k.code] = hold
        pump()
    }

    private fun release(code: Int) {
        val h = holds[code] ?: return
        h.release = true
        pump()
    }

    /** Joystick digital: segura um toque no centro e leva até a borda na direção das teclas. */
    private fun updateJoy(joy: JoyDef) {
        val (w, h) = screen()
        val cx = joy.x * w
        val cy = joy.y * h
        var dx = 0f
        var dy = 0f
        if (joy.right in joyDown) dx += 1f
        if (joy.left in joyDown) dx -= 1f
        if (joy.down in joyDown) dy += 1f
        if (joy.up in joyDown) dy -= 1f
        val cur = holds[JOY_ID]
        if (dx == 0f && dy == 0f) {
            if (cur != null) {
                cur.release = true
                pump()
            }
            return
        }
        val len = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        val reach = dp(joy.radius) * 0.8f
        val tx = cx + dx / len * reach
        val ty = cy + dy / len * reach
        if (cur == null) {
            val n = Hold(cx, cy)
            n.joy = true
            n.tx = tx
            n.ty = ty
            holds[JOY_ID] = n
        } else {
            cur.release = false
            cur.cx = cx
            cur.cy = cy
            cur.tx = tx
            cur.ty = ty
        }
        pump()
    }

    /** Mantém os toques segurados: cada envio continua o anterior até soltar. */
    private fun pump() {
        if (dispatching || holds.isEmpty()) return
        try {
            val now = SystemClock.uptimeMillis()
            val builder = GestureDescription.Builder()
            val ended = ArrayList<Int>()
            for ((id, h) in holds) {
                val path = Path()
                path.moveTo(h.x, h.y)
                var dur = 10L
                if (h.joy) {
                    val ex = if (h.release) h.cx else h.tx
                    val ey = if (h.release) h.cy else h.ty
                    if (ex != h.x || ey != h.y) path.lineTo(ex, ey)
                    h.x = ex
                    h.y = ey
                    dur = 40L
                } else if (h.cam) {
                    if (now - camLast > 250) h.release = true
                    if (!h.release && (h.tx != h.x || h.ty != h.y)) {
                        path.lineTo(h.tx, h.ty)
                        h.x = h.tx
                        h.y = h.ty
                    }
                    dur = 16L
                }
                val cont = !h.release
                val prev = h.stroke
                val s = if (prev != null) prev.continueStroke(path, 0L, dur, cont)
                else GestureDescription.StrokeDescription(path, 0L, dur, cont)
                h.stroke = s
                builder.addStroke(s)
                if (h.release) ended.add(id)
            }
            for (c in ended) holds.remove(c)
            dispatching = true
            lastDispatch = now
            val ok = dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    dispatching = false
                    pump()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    dispatching = false
                    holds.clear()
                }
            }, null)
            if (!ok) {
                dispatching = false
                holds.clear()
            }
        } catch (e: Exception) {
            dispatching = false
            holds.clear()
        }
    }

    // ------------------------------------------------------------ mouse capturado: câmera e botões

    private fun desiredCapture() =
        gamePkg != null && needCapture() && !typing && !manualFree && !fastActive && work == null

    private fun applyCapture() {
        setCapture(desiredCapture())
    }

    private fun setCapture(on: Boolean) {
        val v = capView ?: return
        if (on == wantCapture) return
        wantCapture = on
        if (on) {
            capLp.flags = LS or NT
            wm.updateViewLayout(v, capLp)
            v.requestFocus()
            v.requestPointerCapture()
            ui.postDelayed({
                if (wantCapture && !captured && capWarn < 3) {
                    capWarn++
                    Toast.makeText(
                        this,
                        "O Android não liberou a captura do mouse. Veja a barra: Captura OFF",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }, 1500)
        } else {
            v.releasePointerCapture()
            capLp.flags = NF or NT or LS
            wm.updateViewLayout(v, capLp)
            releaseCameraAndMouse()
        }
    }

    fun captureChanged(has: Boolean) {
        captured = has
        if (!has) releaseCameraAndMouse()
    }

    fun focusChanged(has: Boolean, v: View) {
        if (has && wantCapture) v.requestPointerCapture()
    }

    private fun fastToggle() {
        if (manualFree) return
        fastActive = true
        applyCapture()
        ui.removeCallbacks(recapture)
        ui.postDelayed(recapture, saved.fastMs.toLong())
    }

    private fun manualToggle() {
        ui.removeCallbacks(recapture)
        fastActive = false
        manualFree = !manualFree
        applyCapture()
        Toast.makeText(
            this,
            if (manualFree) "Cursor livre. Aperte a mesma tecla para voltar à câmera" else "Câmera ativa",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun onCaptured(e: MotionEvent) {
        if (gamePkg == null || work != null) return
        // botões do mouse
        val bs = e.buttonState
        val diff = bs xor lastButtons
        if (diff != 0) {
            val bits = intArrayOf(
                MotionEvent.BUTTON_PRIMARY, MotionEvent.BUTTON_SECONDARY, MotionEvent.BUTTON_TERTIARY,
                MotionEvent.BUTTON_BACK, MotionEvent.BUTTON_FORWARD
            )
            for (i in bits.indices) {
                if ((diff and bits[i]) != 0) {
                    val code = -(i + 1)
                    if ((bs and bits[i]) != 0) {
                        val k = saved.keys.firstOrNull { it.code == code }
                        if (k != null && !typing && !holds.containsKey(code)) press(k, false)
                    } else {
                        release(code)
                    }
                }
            }
            lastButtons = bs
        }
        // movimento relativo do mouse
        val a = e.actionMasked
        if ((a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_HOVER_MOVE) &&
            (e.source and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
        ) {
            var dx = e.x
            var dy = e.y
            for (i in 0 until e.historySize) {
                dx += e.getHistoricalX(i)
                dy += e.getHistoricalY(i)
            }
            if (dx != 0f || dy != 0f) {
                lastDx = dx
                lastDy = dy
                infoTv?.text = "Último movimento: dx=${"%.1f".format(dx)} dy=${"%.1f".format(dy)} • Captura: ${if (captured) "ativa" else "inativa"}"
                if (!typing && !manualFree && !fastActive) moveCamera(dx, dy)
            }
        }
    }

    /** Converte o movimento do mouse em arrasto na região da câmera, já com as sensibilidades. */
    private fun moveCamera(dx: Float, dy: Float) {
        val km = saved
        val cam = km.cam ?: return
        val (w, h) = screen()
        val cx = cam.x * w
        val cy = cam.y * h
        val lim = dp(cam.radius) * 0.8f
        val speed = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        var gain = 1f + (km.accel / 100f) * Math.min(speed / 20f, 3f)
        if (speed < 6f) gain *= 1f - (km.prec / 100f) * 0.6f
        val base = (km.sensG / 100f) * (km.sensC / 100f)
        val mx = dx * base * (km.sensX / 100f) * gain
        val my = dy * base * (km.sensY / 100f) * gain * (if (km.invY) -1f else 1f)
        camLast = SystemClock.uptimeMillis()
        var hold = holds[CAM_ID]
        if (hold != null && hold.release) {
            pendX += mx
            pendY += my
            pump()
            return
        }
        if (hold == null) {
            hold = Hold(cx, cy)
            hold.cam = true
            holds[CAM_ID] = hold
            offX = pendX
            offY = pendY
            pendX = 0f
            pendY = 0f
        }
        offX += mx
        offY += my
        if (Math.abs(offX) > lim || Math.abs(offY) > lim) {
            // chegou na borda: levanta o dedo aqui e recomeça do centro
            pendX = offX - (hold.x - cx)
            pendY = offY - (hold.y - cy)
            offX = 0f
            offY = 0f
            hold.release = true
        } else {
            hold.tx = cx + offX
            hold.ty = cy + offY
        }
        pump()
    }

    // ------------------------------------------------------------ ajudantes de tela

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun pill(color: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun circle(sel: Boolean, color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (sel) color else Color.parseColor("#B3000000"))
        setStroke(dp(2), if (sel) Color.WHITE else color)
    }

    private fun btn(label: String, hot: Boolean = false, small: Boolean = false, onClick: () -> Unit) =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = if (small) 12f else 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            if (small) setPadding(dp(6), dp(7), dp(6), dp(7)) else setPadding(dp(12), dp(9), dp(12), dp(9))
            background = pill(
                if (hot) NEON else Color.parseColor("#201215"),
                if (hot) NEON else Color.parseColor("#3D1A20"), 10
            )
            setOnClickListener { onClick() }
        }

    private fun margins(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(WRAP, WRAP).apply {
            marginStart = dp(4)
            marginEnd = dp(4)
        }

    private fun label(t: String, size: Float = 12f): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = size
        return tv
    }

    private fun safeAdd(v: View, lp: WindowManager.LayoutParams) {
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível mostrar os controles sobre o jogo", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeWin(v: View?) {
        if (v != null) {
            try { wm.removeView(v) } catch (e: Exception) { }
        }
    }

    /** touch = parte que recebe o dedo; win = a janela inteira que se move. */
    private fun makeDraggable(touch: View, win: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)?, onDone: () -> Unit) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        touch.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (moved || Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                        if (!moved) closeMenu()
                        moved = true
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        wm.updateViewLayout(win, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onDone() else onTap?.invoke()
                }
            }
            true
        }
    }

    private fun uiPrefs() = getSharedPreferences("ui", Context.MODE_PRIVATE)

    // ------------------------------------------------------------ janelas por cima do jogo

    private fun buildLayer() {
        val l = FrameLayout(this)
        layerLp = lpOf(MATCH, MATCH, NF or NT or LS)
        safeAdd(l, layerLp)
        layer = l
    }

    private fun buildCapture() {
        val v = CaptureView(this, this)
        capLp = lpOf(MATCH, MATCH, NF or NT or LS)
        wantCapture = false
        safeAdd(v, capLp)
        capView = v
    }

    private fun buildBar() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = pill(Color.parseColor("#CC0A0607"), NEON, 12)
        }
        val b = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
        }
        val m = DeviceIcon(this, false)
        val k = DeviceIcon(this, true)
        row.addView(b)
        row.addView(m, LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginStart = dp(10) })
        row.addView(k, LinearLayout.LayoutParams(dp(18), dp(16)).apply { marginStart = dp(8) })
        val prefs = uiPrefs()
        barLp = lpOf(WRAP, WRAP, NF or NM or LS)
        barLp.x = prefs.getInt("bar_x", dp(8))
        barLp.y = prefs.getInt("bar_y", dp(4))
        makeDraggable(row, row, barLp, null) {
            uiPrefs().edit().putInt("bar_x", barLp.x).putInt("bar_y", barLp.y).apply()
        }
        safeAdd(row, barLp)
        bar = row
        batteryTv = b
        mouseIcon = m
        kbIcon = k
        m.color = colorOf(Devices.mouse)
        k.color = colorOf(Devices.keyboard)
        applyBarMode()
    }

    private fun barModeName() = listOf("visível", "discreta", "transparente", "oculta")[uiPrefs().getInt("bar_mode", 0)]

    private fun applyBarMode() {
        val r = bar ?: return
        when (uiPrefs().getInt("bar_mode", 0)) {
            0 -> { r.visibility = View.VISIBLE; r.alpha = 1f }
            1 -> { r.visibility = View.VISIBLE; r.alpha = 0.55f }
            2 -> { r.visibility = View.VISIBLE; r.alpha = 0.25f }
            else -> r.visibility = View.GONE
        }
    }

    private fun cycleBar() {
        val next = (uiPrefs().getInt("bar_mode", 0) + 1) % 4
        uiPrefs().edit().putInt("bar_mode", next).apply()
        applyBarMode()
    }

    private fun buildFab() {
        val v = CrownView(this)
        fabLp = lpOf(dp(48), dp(48), NF or NM or LS)
        fabLp.x = dp(12)
        fabLp.y = dp(80)
        makeDraggable(v, v, fabLp, { toggleMenu() }) { }
        safeAdd(v, fabLp)
        fab = v
    }

    private fun closeMenu() {
        removeWin(menu)
        menu = null
    }

    private fun toggleMenu() {
        if (menu != null) {
            closeMenu()
            return
        }
        if (work != null) {
            Toast.makeText(this, "Termine a edição: Salvar ou Cancelar", Toast.LENGTH_SHORT).show()
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = pill(DARK, NEON, 14)
        }
        val c1 = LinearLayout(this)
        c1.orientation = LinearLayout.VERTICAL
        val c2 = LinearLayout(this)
        c2.orientation = LinearLayout.VERTICAL
        box.addView(c1, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(4) })
        box.addView(c2, LinearLayout.LayoutParams(WRAP, WRAP))
        var n = 0
        fun item(text: String, hot: Boolean = false, a: () -> Unit) {
            val col = if (n % 2 == 0) c1 else c2
            n++
            col.addView(btn(text, hot, true) { a() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        }
        item("Editar keymap") { closeMenu(); enterEdit() }
        item(if (saved.mode == 3) "Mostrar teclas" else "Esconder teclas") {
            toggleVisibility()
            closeMenu()
        }
        item("Sensibilidade") { closeMenu(); openSens() }
        if (needCapture()) {
            item(if (manualFree) "Capturar mouse" else "Liberar mouse") {
                manualToggle()
                closeMenu()
            }
        }
        item("Barra: ${barModeName()}") { cycleBar(); closeMenu() }
        item(if (typing) "Voltar a jogar" else "Digitar no teclado") {
            typing = !typing
            releaseAll()
            applyCapture()
            closeMenu()
            Toast.makeText(
                this,
                if (typing) "Mapeamento pausado: o teclado digita normal" else "Mapeamento ligado",
                Toast.LENGTH_SHORT
            ).show()
        }
        item("Sair do modo jogo", true) { stopGameMode() }
        val p = lpOf(WRAP, WRAP, NF or NM or LS)
        p.x = fabLp.x + dp(56)
        p.y = fabLp.y
        safeAdd(box, p)
        menu = box
    }

    /** Esconde ou mostra só o desenho. Os comandos continuam funcionando do mesmo jeito. */
    private fun toggleVisibility() {
        val pkg = gamePkg ?: return
        if (saved.mode == 3) {
            saved.mode = 0
            if (saved.opacity < 20) saved.opacity = 90
        } else {
            saved.mode = 3
        }
        LayoutStore.save(this, pkg, saved)
        render()
    }

    // ------------------------------------------------------------ desenho das teclas

    private fun render() {
        val l = layer ?: return
        for (i in l.childCount - 1 downTo 0) {
            val t = l.getChildAt(i).tag
            if (t is KeyDef || t is JoyDef || t is CamDef) l.removeViewAt(i)
        }
        val lay = work ?: saved
        val editing = work != null
        if (!editing && lay.mode == 3) return
        val w = if (l.width > 0) l.width else screen().first
        val h = if (l.height > 0) l.height else screen().second
        val a = if (editing) maxOf(lay.opacity / 100f, 0.35f) else lay.opacity / 100f
        val color = Keymap.COLORS[lay.color.coerceIn(0, Keymap.COLORS.size - 1)]
        val joy = lay.joy
        if (joy != null) {
            val js = dp(joy.radius * 2)
            val jv = JoyView(this, color, selJoy && editing)
            jv.tag = joy
            jv.alpha = a
            jv.layoutParams = FrameLayout.LayoutParams(js, js).apply {
                leftMargin = (joy.x * w - js / 2).toInt()
                topMargin = (joy.y * h - js / 2).toInt()
            }
            if (editing) jv.setOnTouchListener(dragJoy(joy))
            l.addView(jv)
        }
        val cam = lay.cam
        if (cam != null) {
            val cs = dp(cam.radius * 2)
            val cv = CamView(this, color, selCam && editing)
            cv.tag = cam
            cv.alpha = a
            cv.layoutParams = FrameLayout.LayoutParams(cs, cs).apply {
                leftMargin = (cam.x * w - cs / 2).toInt()
                topMargin = (cam.y * h - cs / 2).toInt()
            }
            if (editing) cv.setOnTouchListener(dragCam(cam))
            l.addView(cv)
        }
        for (k in lay.keys) {
            val s = dp(k.size)
            val tv = TextView(this)
            tv.tag = k
            tv.text = k.label
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            tv.textSize = if (k.size >= 40) 11f else 9f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.background = circle(k === selKey && editing, color)
            tv.alpha = a
            tv.layoutParams = FrameLayout.LayoutParams(s, s).apply {
                leftMargin = (k.x * w - s / 2).toInt()
                topMargin = (k.y * h - s / 2).toInt()
            }
            if (editing) tv.setOnTouchListener(dragKey(k))
            l.addView(tv)
        }
    }

    private fun paintSelection() {
        val l = layer ?: return
        val lay = work ?: return
        val color = Keymap.COLORS[lay.color.coerceIn(0, Keymap.COLORS.size - 1)]
        for (i in 0 until l.childCount) {
            val c = l.getChildAt(i)
            val t = c.tag
            if (t is KeyDef) {
                c.background = circle(t === selKey, color)
            } else if (t is JoyDef && c is JoyView) {
                c.picked = selJoy
                c.invalidate()
            } else if (t is CamDef && c is CamView) {
                c.picked = selCam
                c.invalidate()
            }
        }
    }

    private fun moveView(v: View, e: MotionEvent, size: Int, minX: Float, maxX: Float, set: (Float, Float) -> Unit) {
        val l = layer ?: return
        val w = if (l.width > 0) l.width else screen().first
        val h = if (l.height > 0) l.height else screen().second
        val fx = (e.rawX / w).coerceIn(minX, maxX)
        val fy = (e.rawY / h).coerceIn(0.02f, 0.98f)
        set(fx, fy)
        val p = v.layoutParams as FrameLayout.LayoutParams
        p.leftMargin = (fx * w - size / 2).toInt()
        p.topMargin = (fy * h - size / 2).toInt()
        v.layoutParams = p
    }

    private fun dragKey(k: KeyDef) = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selKey = k
                selJoy = false
                selCam = false
                paintSelection()
                buildEditUi()
            }
            MotionEvent.ACTION_MOVE -> moveView(v, e, dp(k.size), 0.02f, 0.98f) { fx, fy ->
                k.x = fx
                k.y = fy
            }
            MotionEvent.ACTION_UP -> changed()
        }
        true
    }

    /** O joystick começa na região esquerda (até 55% da largura). */
    private fun dragJoy(j: JoyDef) = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selJoy = true
                selKey = null
                selCam = false
                paintSelection()
                buildEditUi()
            }
            MotionEvent.ACTION_MOVE -> moveView(v, e, dp(j.radius * 2), 0.02f, 0.98f) { fx, fy ->
                j.x = fx
                j.y = fy
            }
            MotionEvent.ACTION_UP -> changed()
        }
        true
    }

    /** A câmera começa na região direita (45% da largura). */
    private fun dragCam(c: CamDef) = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selCam = true
                selKey = null
                selJoy = false
                paintSelection()
                buildEditUi()
            }
            MotionEvent.ACTION_MOVE -> moveView(v, e, dp(c.radius * 2), 0.02f, 0.98f) { fx, fy ->
                c.x = fx
                c.y = fy
            }
            MotionEvent.ACTION_UP -> changed()
        }
        true
    }

    // ------------------------------------------------------------ edição

    /** Grava o rascunho de recuperação. Não toca no layout salvo. */
    private fun changed() {
        val w = work ?: return
        val pkg = gamePkg ?: return
        LayoutStore.saveDraft(this, pkg, w)
    }

    /** Grava a mudança onde ela está: no rascunho (editando) ou no salvo (jogando). */
    private fun persist() {
        if (work != null) {
            changed()
        } else {
            val pkg = gamePkg ?: return
            LayoutStore.save(this, pkg, saved)
        }
    }

    private fun enterEdit() {
        val pkg = gamePkg ?: return
        val draft = LayoutStore.draft(this, pkg)
        if (draft != null) {
            showDialog(
                "Rascunho encontrado",
                "Uma edição anterior não foi salva. Quer continuar de onde parou?",
                listOf(
                    "Restaurar rascunho" to { beginEdit(draft) },
                    "Começar do salvo" to {
                        LayoutStore.clearDraft(this, pkg)
                        beginEdit(saved.copy())
                    },
                    "Fechar" to { }
                )
            )
        } else {
            beginEdit(saved.copy())
        }
    }

    private fun beginEdit(k: Keymap) {
        val l = layer ?: return
        releaseAll()
        work = k
        selKey = null
        selJoy = false
        selCam = false
        waitMouse = false
        applyCapture()
        // sem camada escura: o jogo continua visível durante a edição
        layerLp.flags = NF or LS
        wm.updateViewLayout(l, layerLp)
        l.setOnTouchListener { _, e ->
            if (waitMouse && e.actionMasked == MotionEvent.ACTION_DOWN && e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) {
                val code = mouseCodeFor(e.buttonState)
                val sk = selKey
                if (code != 0 && sk != null) {
                    sk.code = code
                    sk.label = labelFor(code)
                    waitMouse = false
                    changed()
                    render()
                    buildEditUi()
                }
                true
            } else false
        }
        val prefs = uiPrefs()
        editLp = lpOf(dp(250), WRAP, NF or NM or LS)
        editLp.x = prefs.getInt("edit_x", dp(8))
        editLp.y = prefs.getInt("edit_y", dp(8))
        editExpanded = true
        buildEditUi()
        render()
    }

    private fun endEdit() {
        work = null
        selKey = null
        selJoy = false
        selCam = false
        waitMouse = false
        awaitBind = 0
        removeWin(editWin)
        editWin = null
        removeWin(appPanel)
        appPanel = null
        removeWin(sensPanel)
        sensPanel = null
        infoTv = null
        removeWin(dialog)
        dialog = null
        val l = layer
        if (l != null) {
            l.setOnTouchListener(null)
            layerLp.flags = NF or NT or LS
            wm.updateViewLayout(l, layerLp)
        }
        render()
        applyCapture()
    }

    private fun selectedDiameter(): Int? {
        val w = work ?: return null
        val k = selKey
        if (k != null) return k.size
        if (selJoy) return w.joy?.let { it.radius * 2 }
        if (selCam) return w.cam?.let { it.radius * 2 }
        return null
    }

    private fun setSelectedDiameter(v: Int, lo: Int, hi: Int) {
        val w = work ?: return
        val d = v.coerceIn(lo, hi)
        val k = selKey
        if (k != null) k.size = d
        else if (selJoy) w.joy?.radius = d / 2
        else if (selCam) w.cam?.radius = d / 2
        changed()
        render()
    }

    /** Painel compacto, flutuante e recolhível. Toque no título para abrir ou fechar; arraste para mover. */
    private fun buildEditUi() {
        if (work == null) return
        removeWin(editWin)
        editWin = null
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(6), dp(4), dp(6), dp(6))
        col.background = pill(DARK, NEON, 12)
        val head = TextView(this)
        head.text = if (editExpanded) "EDITOR  ▾" else "EDITOR  ▸"
        head.setTextColor(Color.WHITE)
        head.textSize = 12f
        head.typeface = Typeface.DEFAULT_BOLD
        head.gravity = Gravity.CENTER
        head.setPadding(dp(10), dp(6), dp(10), dp(6))
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        if (editExpanded) {
            fun pair(a: View, b: View, wa: Float = 1f, wb: Float = 1f) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.addView(a, LinearLayout.LayoutParams(0, WRAP, wa).apply { marginEnd = dp(2) })
                r.addView(b, LinearLayout.LayoutParams(0, WRAP, wb).apply { marginStart = dp(2) })
                col.addView(r, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(3) })
            }
            pair(btn("+ Tecla", false, true) { addKey() }, btn("+ Mouse", false, true) { addMouseKey() })
            pair(btn("+ Joystick", false, true) { addJoy() }, btn("+ Câmera", false, true) { addCam() })
            pair(btn("Modelo", false, true) { applyTemplate() }, btn("Excluir", false, true) { deleteSelected() })
            pair(btn("Aparência", false, true) { toggleAppearance() }, btn("Câm./Sens.", false, true) { openSens() })

            // tamanho individual do item selecionado
            val cur = selectedDiameter()
            val lo = if (selKey != null) 28 else 60
            val hi = if (selKey != null) 96 else 200
            val tv = label(if (cur != null) "Tamanho: $cur dp" else "Toque num item para ajustar o tamanho", 11f)
            tv.setPadding(0, dp(6), 0, 0)
            col.addView(tv)
            if (cur != null) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.addView(btn("−", false, true) {
                    setSelectedDiameter(cur - 2, lo, hi)
                    buildEditUi()
                }, LinearLayout.LayoutParams(dp(34), WRAP))
                val sb = SeekBar(this)
                sb.max = hi - lo
                sb.progress = (cur - lo).coerceIn(0, hi - lo)
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) {
                            setSelectedDiameter(p + lo, lo, hi)
                            tv.text = "Tamanho: ${p + lo} dp"
                        }
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {}

                    override fun onStopTrackingTouch(s: SeekBar?) {
                        changed()
                    }
                })
                r.addView(sb, LinearLayout.LayoutParams(0, WRAP, 1f))
                r.addView(btn("+", false, true) {
                    setSelectedDiameter(cur + 2, lo, hi)
                    buildEditUi()
                }, LinearLayout.LayoutParams(dp(34), WRAP))
                col.addView(r)
            }
            pair(btn("Cancelar", false, true) { onCancel() }, btn("SALVAR KEYMAP", true, true) { onSave() }, 0.8f, 1.2f)
            val hint = label("Toque numa bolinha e aperte a tecla do teclado. Para botão do mouse use + Mouse.", 10f)
            hint.setPadding(0, dp(4), 0, 0)
            col.addView(hint)
        }
        makeDraggable(head, col, editLp, {
            editExpanded = !editExpanded
            buildEditUi()
        }) {
            uiPrefs().edit().putInt("edit_x", editLp.x).putInt("edit_y", editLp.y).apply()
        }
        safeAdd(col, editLp)
        editWin = col
    }

    private fun addKey() {
        val w = work ?: return
        val k = KeyDef(0, "?", 0.5f, 0.5f, w.keySize)
        w.keys.add(k)
        selKey = k
        selJoy = false
        selCam = false
        waitMouse = false
        changed()
        render()
        buildEditUi()
    }

    private fun addMouseKey() {
        val w = work ?: return
        val k = KeyDef(0, "?", 0.5f, 0.5f, w.keySize)
        w.keys.add(k)
        selKey = k
        selJoy = false
        selCam = false
        waitMouse = true
        changed()
        render()
        buildEditUi()
        Toast.makeText(this, "Agora clique o botão do mouse numa área vazia da tela", Toast.LENGTH_LONG).show()
    }

    private fun newJoy() = JoyDef(
        0.18f, 0.68f, 60,
        KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D
    )

    private fun newCam() = CamDef(0.78f, 0.45f, 50)

    private fun addJoy() {
        val w = work ?: return
        if (w.joy != null) {
            Toast.makeText(this, "Já existe um joystick", Toast.LENGTH_SHORT).show()
            return
        }
        w.joy = newJoy()
        selJoy = true
        selKey = null
        selCam = false
        changed()
        render()
        buildEditUi()
        Toast.makeText(this, "Joystick nas teclas W A S D (8 direções, digital)", Toast.LENGTH_LONG).show()
    }

    private fun addCam() {
        val w = work ?: return
        if (w.cam != null) {
            Toast.makeText(this, "Já existe um controle de câmera", Toast.LENGTH_SHORT).show()
            return
        }
        w.cam = newCam()
        selCam = true
        selKey = null
        selJoy = false
        changed()
        render()
        buildEditUi()
        Toast.makeText(this, "Arraste a bolinha até o botão Visualizar do jogo", Toast.LENGTH_LONG).show()
    }

    private fun deleteSelected() {
        val w = work ?: return
        val sk = selKey
        if (sk != null) {
            w.keys.remove(sk)
            selKey = null
        } else if (selJoy) {
            w.joy = null
            selJoy = false
        } else if (selCam) {
            w.cam = null
            selCam = false
        } else {
            Toast.makeText(this, "Toque num item primeiro", Toast.LENGTH_SHORT).show()
            return
        }
        changed()
        render()
        buildEditUi()
    }

    private fun applyTemplate() {
        val w = work ?: return
        w.keys.clear()
        w.keys.add(KeyDef(KeyEvent.KEYCODE_F, "F", 0.62f, 0.72f, w.keySize))
        w.keys.add(KeyDef(KeyEvent.KEYCODE_R, "R", 0.92f, 0.34f, w.keySize))
        w.keys.add(KeyDef(KeyEvent.KEYCODE_SPACE, "Esp", 0.90f, 0.62f, w.keySize))
        if (w.joy == null) w.joy = newJoy()
        if (w.cam == null) w.cam = newCam()
        selKey = null
        selJoy = false
        selCam = false
        changed()
        render()
        buildEditUi()
    }

    private fun onSave() {
        val w = work ?: return
        val pkg = gamePkg ?: return
        w.keys.removeAll { it.code == 0 }
        LayoutStore.save(this, pkg, w)
        LayoutStore.clearDraft(this, pkg)
        saved = w
        endEdit()
        Toast.makeText(this, "Keymap salvo", Toast.LENGTH_SHORT).show()
    }

    private fun onCancel() {
        val w = work ?: return
        if (w.toJson() == saved.toJson()) {
            discardEdit()
            return
        }
        showDialog(
            "Alterações não salvas",
            "O layout salvo continua intacto. O que você quer fazer?",
            listOf(
                "Salvar e sair" to { onSave() },
                "Descartar alterações" to { discardEdit() },
                "Continuar editando" to { }
            )
        )
    }

    private fun discardEdit() {
        val pkg = gamePkg ?: return
        LayoutStore.clearDraft(this, pkg)
        endEdit()
    }

    private fun showDialog(title: String, msg: String, opts: List<Pair<String, () -> Unit>>) {
        removeWin(dialog)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = pill(DARK, NEON, 14)
        }
        val t = label(title, 16f)
        t.typeface = Typeface.DEFAULT_BOLD
        col.addView(t)
        val m = label(msg, 13f)
        m.setTextColor(Color.parseColor("#C9BCBE"))
        m.setPadding(0, dp(6), 0, dp(8))
        col.addView(m)
        for ((text, action) in opts) {
            col.addView(btn(text, text.startsWith("Salvar") || text.startsWith("Restaurar")) {
                removeWin(dialog)
                dialog = null
                action()
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        }
        val p = lpOf(dp(300), WRAP, NF or NM or LS)
        p.gravity = Gravity.CENTER
        safeAdd(col, p)
        dialog = col
    }

    // ------------------------------------------------------------ painéis de ajuste

    private fun seekRow(text: String, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = label("$text: $value")
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (value - min).coerceIn(0, max - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val v = p + min
                    t.text = "$text: $v"
                    onChange(v)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                persist()
            }
        })
        col.addView(t)
        col.addView(sb, LinearLayout.LayoutParams(dp(250), WRAP))
        return col
    }

    private fun panelBox(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(10), dp(12), dp(10))
        return col
    }

    private fun scrollWin(col: View, x: Int, y: Int, width: Int): ScrollView {
        val sv = ScrollView(this)
        sv.background = pill(DARK, NEON, 14)
        sv.addView(col)
        val p = lpOf(width, (screen().second * 0.78f).toInt(), NF or NM or LS)
        p.x = x
        p.y = y
        safeAdd(sv, p)
        return sv
    }

    private fun toggleAppearance() {
        if (appPanel != null) {
            removeWin(appPanel)
            appPanel = null
            return
        }
        openAppearance()
    }

    private fun reopenAppearance() {
        removeWin(appPanel)
        appPanel = null
        openAppearance()
    }

    private fun openAppearance() {
        val w = work ?: return
        val col = panelBox()
        val title = label("Aparência das teclas", 13f)
        title.typeface = Typeface.DEFAULT_BOLD
        col.addView(title)
        val modes = LinearLayout(this)
        modes.orientation = LinearLayout.HORIZONTAL
        val names = listOf("Visível", "Discreto", "Transp.", "Oculto")
        val presets = intArrayOf(90, 45, 20, -1)
        names.forEachIndexed { i, n ->
            modes.addView(btn(n, w.mode == i, true) {
                w.mode = i
                if (presets[i] >= 0) w.opacity = presets[i]
                changed()
                render()
                reopenAppearance()
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            })
        }
        col.addView(modes, LinearLayout.LayoutParams(dp(250), WRAP).apply { topMargin = dp(6) })
        col.addView(seekRow("Opacidade (%)", 0, 100, w.opacity) { v ->
            w.opacity = v
            render()
        })
        val sws = LinearLayout(this)
        sws.orientation = LinearLayout.HORIZONTAL
        Keymap.COLORS.forEachIndexed { i, c ->
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(dp(2), if (w.color == i) Color.WHITE else Color.TRANSPARENT)
            }
            dot.setOnClickListener {
                w.color = i
                changed()
                render()
                reopenAppearance()
            }
            sws.addView(dot, LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                marginEnd = dp(8)
                topMargin = dp(8)
            })
        }
        col.addView(sws)
        appPanel = scrollWin(col, dp(270), dp(8), dp(280))
    }

    private fun reopenSens() {
        if (sensPanel == null) return
        removeWin(sensPanel)
        sensPanel = null
        openSens()
    }

    /** Sensibilidade, precisão, aceleração e teclas de alternância. Funciona jogando ou editando. */
    private fun openSens() {
        if (sensPanel != null) {
            removeWin(sensPanel)
            sensPanel = null
            infoTv = null
            return
        }
        val t = work ?: saved
        val col = panelBox()
        val title = label("Câmera e sensibilidade", 13f)
        title.typeface = Typeface.DEFAULT_BOLD
        col.addView(title)
        val info = label("Mova o mouse para ver os números (precisa da captura ativa).", 11f)
        info.setTextColor(Color.parseColor("#C9BCBE"))
        info.layoutParams = LinearLayout.LayoutParams(dp(250), WRAP)
        col.addView(info)
        infoTv = info
        col.addView(seekRow("Sensibilidade geral (%)", 10, 300, t.sensG) { t.sensG = it })
        col.addView(seekRow("Horizontal X (%)", 10, 300, t.sensX) { t.sensX = it })
        col.addView(seekRow("Vertical Y (%)", 10, 300, t.sensY) { t.sensY = it })
        col.addView(seekRow("Câmera (%)", 10, 300, t.sensC) { t.sensC = it })
        col.addView(seekRow("Aceleração", 0, 100, t.accel) { t.accel = it })
        col.addView(seekRow("Precisão (movimentos lentos)", 0, 100, t.prec) { t.prec = it })
        col.addView(btn(if (t.invY) "Inverter Y: ligado" else "Inverter Y: desligado", t.invY, true) {
            t.invY = !t.invY
            persist()
            reopenSens()
        }, LinearLayout.LayoutParams(dp(250), WRAP).apply { topMargin = dp(6) })
        col.addView(seekRow("Cursor livre (ms)", 200, 2000, t.fastMs) { t.fastMs = it })
        fun keyName(c: Int) = if (c == 0) "nenhuma" else labelFor(c)
        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        r1.addView(btn("Rápida: ${keyName(t.fastKey)}", false, true) {
            awaitBind = 1
            Toast.makeText(this, "Aperte a tecla da alternância rápida", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(2) })
        r1.addView(btn("Limpar", false, true) {
            t.fastKey = 0
            persist()
            reopenSens()
        }, LinearLayout.LayoutParams(dp(60), WRAP))
        col.addView(r1, LinearLayout.LayoutParams(dp(250), WRAP).apply { topMargin = dp(6) })
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.addView(btn("Manual: ${keyName(t.manualKey)}", false, true) {
            awaitBind = 2
            Toast.makeText(this, "Aperte a tecla da alternância manual", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(2) })
        r2.addView(btn("Limpar", false, true) {
            t.manualKey = 0
            persist()
            reopenSens()
        }, LinearLayout.LayoutParams(dp(60), WRAP))
        col.addView(r2, LinearLayout.LayoutParams(dp(250), WRAP).apply { topMargin = dp(4) })
        sensPanel = scrollWin(col, dp(8), dp(8), dp(280))
    }
}
