package br.com.santosmousegg

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val NEON = Color.parseColor("#E5202E")
private val DARK = Color.parseColor("#F0150D0F")
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val NF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
private const val NT = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
private const val NM = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
private const val LS = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

private fun lpOf(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
    w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
).apply { gravity = Gravity.TOP or Gravity.START }

/** Uma tecla do keymap. x e y são frações da tela (0 a 1). */
class KeyDef(var code: Int, var label: String, var x: Float, var y: Float)

/** Um toque que está sendo segurado no jogo enquanto a tecla está apertada. */
class Hold(val x: Float, val y: Float) {
    var stroke: GestureDescription.StrokeDescription? = null
    var release = false
}

/** Botão redondo com a coroa. */
class CrownView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#E60A0607")
        canvas.drawCircle(w / 2, h / 2, w / 2 - 3f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = NEON
        canvas.drawCircle(w / 2, h / 2, w / 2 - 3f, paint)
        val path = Path().apply {
            moveTo(0.28f * w, 0.68f * h); lineTo(0.20f * w, 0.34f * h); lineTo(0.36f * w, 0.46f * h)
            lineTo(0.50f * w, 0.26f * h); lineTo(0.64f * w, 0.46f * h); lineTo(0.80f * w, 0.34f * h)
            lineTo(0.72f * w, 0.68f * h); close()
        }
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
    }
}

/**
 * O mapeador. Ele é um serviço de acessibilidade: recebe as teclas do teclado,
 * faz os toques na tela do jogo e desenha a coroa, o menu e as teclas por cima.
 */
class MapperService : AccessibilityService() {

    companion object {
        var instance: MapperService? = null
        var enabled by mutableStateOf(false)
    }

    private lateinit var wm: WindowManager
    private lateinit var layerLp: WindowManager.LayoutParams
    private lateinit var fabLp: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())
    private var homePkg = ""
    private var gamePkg: String? = null
    private var keys = mutableListOf<KeyDef>()
    private var showKeys = true
    private var typing = false
    private var editing = false
    private var selected: KeyDef? = null
    private var layer: FrameLayout? = null
    private var fab: View? = null
    private var menu: View? = null
    private var bar: TextView? = null
    private val holds = LinkedHashMap<Int, Hold>()
    private var dispatching = false
    private val taps = ArrayList<Long>()
    private var lastRx = -1L

    // ------------------------------------------------------------ ciclo de vida

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        enabled = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        homePkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName ?: ""
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopGameMode()
        instance = null
        enabled = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.postDelayed({ renderKeys() }, 300)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        if (gamePkg != null && ev.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            homePkg.isNotEmpty() && ev.packageName?.toString() == homePkg
        ) stopGameMode()
    }

    // ------------------------------------------------------------ modo jogo

    fun startGameMode(pkg: String) {
        stopGameMode()
        gamePkg = pkg
        keys = loadKeys(pkg)
        showKeys = true
        typing = false
        editing = false
        selected = null
        buildLayer()
        buildFab()
        buildBar()
        renderKeys()
        ui.post(tick)
    }

    fun stopGameMode() {
        if (!::wm.isInitialized) return
        ui.removeCallbacks(tick)
        holds.clear()
        closeMenu()
        for (v in listOf(layer, fab, bar)) {
            if (v != null) {
                try { wm.removeView(v) } catch (e: Exception) { }
            }
        }
        layer = null
        fab = null
        bar = null
        gamePkg = null
        editing = false
        selected = null
        taps.clear()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (gamePkg == null) return
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
            val rx = TrafficStats.getTotalRxBytes()
            val speed = if (lastRx >= 0 && rx >= 0) (rx - lastRx) / 1024 else 0
            lastRx = rx
            val now = SystemClock.uptimeMillis()
            taps.removeAll { now - it > 1000 }
            val hora = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            bar?.text = "Bateria $pct%  •  $hora  •  Rede $speed KB/s  •  CPS ${taps.size}"
            ui.postDelayed(this, 1000)
        }
    }

    // ------------------------------------------------------------ teclado -> toque

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (gamePkg == null) return false
        val code = event.keyCode
        if (code in setOf(
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_APP_SWITCH,
                KeyEvent.KEYCODE_POWER, KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_UNKNOWN
            )
        ) return false
        if (editing) {
            val sel = selected ?: return false
            if (event.action == KeyEvent.ACTION_DOWN) {
                sel.code = code
                sel.label = labelFor(code)
                renderKeys()
                paintSelection()
            }
            return true
        }
        if (typing) return false
        val k = keys.firstOrNull { it.code == code } ?: return false
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0 && !holds.containsKey(code)) press(k)
        } else if (event.action == KeyEvent.ACTION_UP) {
            release(code)
        }
        return true
    }

    private fun labelFor(code: Int): String = when (code) {
        KeyEvent.KEYCODE_SPACE -> "Esp"
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "Shift"
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "Ctrl"
        KeyEvent.KEYCODE_TAB -> "Tab"
        KeyEvent.KEYCODE_ENTER -> "Enter"
        else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").take(4)
    }

    private fun press(k: KeyDef) {
        val (w, h) = screen()
        holds[k.code] = Hold(k.x * w, k.y * h)
        taps.add(SystemClock.uptimeMillis())
        pump()
    }

    private fun release(code: Int) {
        val h = holds[code] ?: return
        h.release = true
        pump()
    }

    /** Mantém os toques segurados: cada envio continua o anterior até a tecla ser solta. */
    private fun pump() {
        if (dispatching || holds.isEmpty()) return
        val builder = GestureDescription.Builder()
        val ended = ArrayList<Int>()
        for ((code, h) in holds) {
            val path = Path().apply { moveTo(h.x, h.y) }
            val cont = !h.release
            val prev = h.stroke
            val s = if (prev != null) prev.continueStroke(path, 0L, 10L, cont)
            else GestureDescription.StrokeDescription(path, 0L, 10L, cont)
            h.stroke = s
            builder.addStroke(s)
            if (h.release) ended.add(code)
        }
        for (c in ended) holds.remove(c)
        dispatching = true
        val ok = dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                dispatching = false
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                dispatching = false
                holds.clear()
            }
        }, null)
        if (!ok) {
            dispatching = false
            holds.clear()
        }
    }

    // ------------------------------------------------------------ keymap salvo

    private fun prefs() = getSharedPreferences("keymaps", Context.MODE_PRIVATE)

    private fun loadKeys(pkg: String): MutableList<KeyDef> =
        (prefs().getString(pkg, "") ?: "").split("\n").mapNotNull { line ->
            val p = line.split("|")
            if (p.size == 4) {
                KeyDef(
                    p[0].toIntOrNull() ?: return@mapNotNull null,
                    p[1],
                    p[2].toFloatOrNull() ?: 0.5f,
                    p[3].toFloatOrNull() ?: 0.5f
                )
            } else null
        }.toMutableList()

    private fun saveKeys(pkg: String) {
        val text = keys.filter { it.code != 0 }.joinToString("\n") { "${it.code}|${it.label}|${it.x}|${it.y}" }
        prefs().edit().putString(pkg, text).apply()
    }

    // ------------------------------------------------------------ telas por cima do jogo

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun pill(color: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun circle(sel: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (sel) NEON else Color.parseColor("#B3000000"))
        setStroke(dp(2), NEON)
    }

    private fun btn(label: String, hot: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = pill(
            if (hot) NEON else Color.parseColor("#201215"),
            if (hot) NEON else Color.parseColor("#3D1A20"), 12
        )
        setOnClickListener { onClick() }
    }

    private fun safeAdd(v: View, lp: WindowManager.LayoutParams) {
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível mostrar os controles sobre o jogo", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildLayer() {
        val l = FrameLayout(this)
        layerLp = lpOf(MATCH, MATCH, NF or NT or LS)
        safeAdd(l, layerLp)
        layer = l
    }

    private fun buildBar() {
        val t = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = pill(Color.parseColor("#B3000000"), 0, 10)
        }
        val p = lpOf(WRAP, WRAP, NF or NT or LS).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(2)
        }
        safeAdd(t, p)
        bar = t
    }

    private fun buildFab() {
        val v = CrownView(this)
        fabLp = lpOf(dp(48), dp(48), NF or NM or LS)
        fabLp.x = dp(12)
        fabLp.y = dp(80)
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = fabLp.x; oy = fabLp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (moved || Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                        if (!moved) closeMenu()
                        moved = true
                        fabLp.x = ox + dx.toInt()
                        fabLp.y = oy + dy.toInt()
                        wm.updateViewLayout(v, fabLp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleMenu()
                }
            }
            true
        }
        safeAdd(v, fabLp)
        fab = v
    }

    private fun closeMenu() {
        val m = menu
        if (m != null) {
            try { wm.removeView(m) } catch (e: Exception) { }
        }
        menu = null
    }

    private fun toggleMenu() {
        if (menu != null) {
            closeMenu()
            return
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = pill(DARK, NEON, 14)
        }
        fun item(label: String, hot: Boolean = false, a: () -> Unit) {
            col.addView(btn(label, hot) { a() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        }
        item("Editar keymap") { closeMenu(); enterEdit() }
        item(if (showKeys) "Esconder teclas" else "Mostrar teclas") {
            showKeys = !showKeys
            closeMenu()
            renderKeys()
        }
        item(if (typing) "Voltar a jogar" else "Digitar no teclado") {
            typing = !typing
            closeMenu()
            Toast.makeText(
                this,
                if (typing) "Mapeamento pausado: o teclado digita normal" else "Mapeamento ligado",
                Toast.LENGTH_SHORT
            ).show()
        }
        item("Sair do modo jogo", true) { stopGameMode() }
        val p = lpOf(WRAP, WRAP, NF or NM or LS)
        p.x = fabLp.x + dp(56)
        p.y = fabLp.y
        safeAdd(col, p)
        menu = col
    }

    // ------------------------------------------------------------ bolinhas e edição

    private fun renderKeys() {
        val l = layer ?: return
        for (i in l.childCount - 1 downTo 0) {
            if (l.getChildAt(i).tag is KeyDef) l.removeViewAt(i)
        }
        if (!showKeys && !editing) return
        val w = if (l.width > 0) l.width else screen().first
        val h = if (l.height > 0) l.height else screen().second
        val s = dp(44)
        for (k in keys) {
            val tv = TextView(this).apply {
                tag = k
                text = k.label
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                background = circle(k === selected)
                layoutParams = FrameLayout.LayoutParams(s, s).apply {
                    leftMargin = (k.x * w - s / 2).toInt()
                    topMargin = (k.y * h - s / 2).toInt()
                }
            }
            if (editing) tv.setOnTouchListener(dragger(k))
            l.addView(tv)
        }
    }

    private fun paintSelection() {
        val l = layer ?: return
        for (i in 0 until l.childCount) {
            val c = l.getChildAt(i)
            val t = c.tag
            if (t is KeyDef) c.background = circle(t === selected)
        }
    }

    private fun dragger(k: KeyDef) = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selected = k
                paintSelection()
            }
            MotionEvent.ACTION_MOVE -> {
                val l = layer
                if (l != null) {
                    val w = if (l.width > 0) l.width else screen().first
                    val h = if (l.height > 0) l.height else screen().second
                    k.x = (e.rawX / w).coerceIn(0.02f, 0.98f)
                    k.y = (e.rawY / h).coerceIn(0.02f, 0.98f)
                    val s = dp(44)
                    val p = v.layoutParams as FrameLayout.LayoutParams
                    p.leftMargin = (k.x * w - s / 2).toInt()
                    p.topMargin = (k.y * h - s / 2).toInt()
                    v.layoutParams = p
                }
            }
        }
        true
    }

    private fun enterEdit() {
        val l = layer ?: return
        editing = true
        selected = null
        layerLp.flags = NF or LS
        l.setBackgroundColor(Color.parseColor("#99000000"))
        wm.updateViewLayout(l, layerLp)
        val hint = TextView(this).apply {
            tag = "ui"
            text = "Toque numa bolinha e aperte a tecla do teclado para vincular. Arraste para mover."
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = pill(DARK, NEON, 12)
        }
        l.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(40)
        })
        val row = LinearLayout(this).apply {
            tag = "ui"
            orientation = LinearLayout.HORIZONTAL
        }
        fun add(label: String, hot: Boolean = false, a: () -> Unit) {
            row.addView(btn(label, hot) { a() }, LinearLayout.LayoutParams(WRAP, WRAP).apply {
                marginStart = dp(6)
                marginEnd = dp(6)
            })
        }
        add("Modelo") { applyTemplate() }
        add("Adicionar") {
            val k = KeyDef(0, "?", 0.5f, 0.5f)
            keys.add(k)
            selected = k
            renderKeys()
        }
        add("Excluir") {
            val sel = selected
            if (sel != null) keys.remove(sel)
            selected = null
            renderKeys()
        }
        add("Cancelar") { exitEdit(false) }
        add("Salvar", true) { exitEdit(true) }
        l.addView(row, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(24)
        })
        renderKeys()
    }

    private fun exitEdit(save: Boolean) {
        val l = layer ?: return
        val pkg = gamePkg ?: return
        for (i in l.childCount - 1 downTo 0) {
            if (l.getChildAt(i).tag == "ui") l.removeViewAt(i)
        }
        editing = false
        selected = null
        if (save) {
            keys = keys.filter { it.code != 0 }.toMutableList()
            saveKeys(pkg)
            Toast.makeText(this, "Keymap salvo", Toast.LENGTH_SHORT).show()
        } else {
            keys = loadKeys(pkg)
        }
        l.setBackgroundColor(Color.TRANSPARENT)
        layerLp.flags = NF or NT or LS
        wm.updateViewLayout(l, layerLp)
        renderKeys()
    }

    private fun applyTemplate() {
        keys.clear()
        keys.add(KeyDef(KeyEvent.KEYCODE_W, "W", 0.14f, 0.60f))
        keys.add(KeyDef(KeyEvent.KEYCODE_A, "A", 0.08f, 0.74f))
        keys.add(KeyDef(KeyEvent.KEYCODE_S, "S", 0.14f, 0.88f))
        keys.add(KeyDef(KeyEvent.KEYCODE_D, "D", 0.20f, 0.74f))
        keys.add(KeyDef(KeyEvent.KEYCODE_F, "F", 0.80f, 0.72f))
        keys.add(KeyDef(KeyEvent.KEYCODE_R, "R", 0.92f, 0.36f))
        keys.add(KeyDef(KeyEvent.KEYCODE_SPACE, "Esp", 0.90f, 0.56f))
        selected = null
        renderKeys()
    }
}
