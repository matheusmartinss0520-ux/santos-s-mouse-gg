package br.com.santosmousegg

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.input.pointer.pointerInput

/** Seta vermelho neon com borda branca e preta, para ter contraste em fundo claro e escuro. */
private fun neonCursor(): Bitmap {
    val bmp = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val path = Path().apply {
        moveTo(5f, 3f); lineTo(5f, 34f); lineTo(13f, 27f); lineTo(19f, 41f)
        lineTo(25f, 38f); lineTo(19f, 25f); lineTo(30f, 25f); close()
    }
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.strokeJoin = Paint.Join.ROUND
    p.style = Paint.Style.STROKE
    p.strokeWidth = 6f
    p.color = Color.BLACK
    c.drawPath(path, p)
    p.strokeWidth = 3f
    p.color = Color.WHITE
    c.drawPath(path, p)
    p.style = Paint.Style.FILL
    p.color = Color.parseColor("#FF1A2E")
    c.drawPath(path, p)
    return bmp
}

@OptIn(ExperimentalComposeUiApi::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SantosTheme {
                // cursor de verdade (PointerIcon do Android), só dentro do app
                val cursor = remember { PointerIcon(android.view.PointerIcon.create(neonCursor(), 5f, 3f)) }
                Surface(
                    Modifier.fillMaxSize()
                        .pointerHoverIcon(cursor, overrideDescendants = true)
                        .pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val e = awaitPointerEvent(PointerEventPass.Initial)
                                    if (e.changes.any { it.type == PointerType.Mouse }) Devices.markMouseSeen()
                                }
                            }
                        },
                    color = Bg
                ) { App() }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Devices.start(applicationContext)
    }

    override fun onStop() {
        super.onStop()
        Devices.stop()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val d = event.device
        if (d != null && !d.isVirtual && d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC) {
            Devices.markKeyboardSeen()
        }
        return super.dispatchKeyEvent(event)
    }
}
