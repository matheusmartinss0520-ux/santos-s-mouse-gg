package br.com.santosmousegg

import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SantosTheme {
                Surface(
                    Modifier.fillMaxSize().pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val e = awaitPointerEvent(PointerEventPass.Initial)
                                if (e.changes.any { it.type == PointerType.Mouse }) Devices.markMouseSeen()
                            }
                        }
                    },
                    color = Bg
                ) { App() }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Devices.start(applicationContext)
    }

    override fun onStop() {
        super.onStop()
        Devices.stop()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val d = event.device
        if (d != null && !d.isVirtual && d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC) {
            Devices.markKeyboardSeen()
        }
        return super.dispatchKeyEvent(event)
    }
}
