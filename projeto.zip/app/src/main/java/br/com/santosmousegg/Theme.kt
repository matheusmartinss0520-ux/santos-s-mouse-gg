package br.com.santosmousegg

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0A0607)
val Surface1 = Color(0xFF150D0F)
val Surface2 = Color(0xFF201215)
val LineColor = Color(0xFF3D1A20)
val Red = Color(0xFFE5202E)
val Muted = Color(0xFFA08E91)
val Ok = Color(0xFF32D27A)
val Ink = Color(0xFFF5EEEE)

@Composable
fun SantosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            onPrimary = Color.White,
            background = Bg,
            onBackground = Ink,
            surface = Surface1,
            onSurface = Ink,
            surfaceVariant = Surface2,
            onSurfaceVariant = Muted,
            outline = LineColor
        ),
        content = content
    )
}
