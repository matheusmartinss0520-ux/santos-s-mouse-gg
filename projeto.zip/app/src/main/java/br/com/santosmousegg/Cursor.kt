package br.com.santosmousegg

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.input.pointer.PointerIcon

/** Seta vermelho neon com borda branca e preta, para ter contraste em fundo claro e escuro. */
fun neonCursorBitmap(): Bitmap {
    val bmp = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val path = Path().apply {
        moveTo(5f, 3f); lineTo(5f, 34f); lineTo(13f, 27f); lineTo(19f, 41f)
        lineTo(25f, 38f); lineTo(19f, 25f); lineTo(30f, 25f); close()
    }
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.strokeJoin = Paint.Join.ROUND
    p.style = Paint.Style.STROKE
    p.strokeWidth = 6f
    p.color = Color.BLACK
    c.drawPath(path, p)
    p.strokeWidth = 3f
    p.color = Color.WHITE
    c.drawPath(path, p)
    p.style = Paint.Style.FILL
    p.color = Color.parseColor("#FF1A2E")
    c.drawPath(path, p)
    return bmp
}

/** O cursor real (PointerIcon do Android), usado em todas as telas do app. */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun rememberNeonCursor(): PointerIcon =
    remember { PointerIcon(android.view.PointerIcon.create(neonCursorBitmap(), 5f, 3f)) }
