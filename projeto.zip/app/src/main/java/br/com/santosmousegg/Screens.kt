package br.com.santosmousegg

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Amber = Color(0xFFFFC107)

private fun stateColor(s: DevState): Color = when (s) {
    DevState.OK -> Ok
    DevState.LIMITED -> Amber
    DevState.OFF -> Red
}

// ---------------------------------------------------------------- JOGOS

@Composable
private fun DeviceChip(icon: ImageVector, label: String, state: DevState, onClick: () -> Unit) {
    val word = when (state) {
        DevState.OK -> "funcionando"
        DevState.LIMITED -> "não confirmado"
        DevState.OFF -> "desconectado"
    }
    Row(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).panel().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, "$label: $word", tint = stateColor(state), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 12.sp)
    }
}

@Composable
private fun MapperChip() {
    val on = MapperService.enabled
    Row(
        Modifier.panel().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(if (on) Ok else Muted, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(if (on) "Mapeador ligado" else "Mapeador desligado", fontSize = 12.sp, color = if (on) Ink else Muted)
    }
}

@Composable
private fun DeviceDialog(isMouse: Boolean, onClose: () -> Unit) {
    val state = if (isMouse) Devices.mouse else Devices.keyboard
    val list = if (isMouse) Devices.mouseInfo else Devices.keyboardInfo
    val status = when (state) {
        DevState.OK -> "Reconhecido e funcionando."
        DevState.LIMITED ->
            if (isMouse) "Identificado pelo Android, mas ainda não confirmado. Mova o mouse sobre o app para confirmar."
            else "Identificado pelo Android, mas ainda não confirmado. Aperte uma tecla para confirmar."
        DevState.OFF -> "Desconectado. O Android não listou nenhum aparelho desse tipo."
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (isMouse) "Mouse" else "Teclado") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(status)
                Spacer(Modifier.height(8.dp))
                for (d in list) {
                    Text(d, color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                }
                Text(
                    "Tipo de conexão: o Android não informa se é Bluetooth, USB ou OTG.",
                    color = Muted, fontSize = 12.sp
                )
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fechar") } }
    )
}

@Composable
fun GamesScreen(onAdd: () -> Unit) {
    val ctx = LocalContext.current
    remember { GameLibrary.load(ctx) }
    var info by remember { mutableStateOf<Boolean?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle("Jogos", Modifier.weight(1f))
            DeviceChip(Icons.Filled.Mouse, "Mouse", Devices.mouse) { info = true }
            Spacer(Modifier.width(8.dp))
            DeviceChip(Icons.Filled.Keyboard, "Teclado", Devices.keyboard) { info = false }
            Spacer(Modifier.width(8.dp))
            MapperChip()
            Spacer(Modifier.width(12.dp))
            NeonButton("+ Adicionar jogo", onAdd)
        }
        Spacer(Modifier.height(12.dp))
        val games = GameLibrary.games
        if (games.isEmpty()) {
            Text(
                "Sua biblioteca está vazia. Toque em “+ Adicionar jogo” para escolher um jogo instalado no celular.",
                color = Muted
            )
            Spacer(Modifier.weight(1f))
            CreatorSignature(Modifier.fillMaxWidth())
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(games.toList(), key = { it }) { GameRow(it) }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    CreatorSignature(Modifier.fillMaxWidth().padding(top = 8.dp))
                }
            }
        }
    }
    val which = info
    if (which != null) DeviceDialog(which) { info = null }
}

@Composable
private fun GameRow(pkg: String) {
    val ctx = LocalContext.current
    val info = remember(pkg) { appInfoOrNull(ctx, pkg) }
    var confirm by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().panel().padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (info != null) {
            Image(info.icon, null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
        } else {
            Box(Modifier.size(48.dp).background(Surface2, RoundedCornerShape(12.dp)))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(info?.name ?: pkg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (info != null) "Instalado" else "Não instalado",
                color = if (info != null) Ok else Muted,
                fontSize = 12.sp
            )
        }
        IconButton(onClick = { confirm = true }) {
            Icon(Icons.Filled.Delete, "Remover da biblioteca", tint = Muted)
        }
        NeonButton("Iniciar", { startGame(ctx, pkg) }, enabled = info != null)
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Remover da biblioteca?") },
            text = { Text("O jogo continua instalado no celular. Ele só sai da lista do Santos Mouse GG.") },
            confirmButton = {
                TextButton(onClick = { GameLibrary.remove(ctx, pkg); confirm = false }) {
                    Text("Remover", color = Red)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } }
        )
    }
}

/** Abre o jogo e liga a coroa, as teclas e a barra por cima dele. */
fun startGame(ctx: Context, pkg: String) {
    val svc = MapperService.instance
    if (svc == null) {
        Toast.makeText(ctx, "Ligue o Santos Mouse GG em Acessibilidade para usar o mapeador", Toast.LENGTH_LONG).show()
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        return
    }
    if (launchApp(ctx, pkg)) {
        svc.startGameMode(pkg)
    } else {
        Toast.makeText(ctx, "Não foi possível abrir o jogo", Toast.LENGTH_SHORT).show()
    }
}

// ---------------------------------------------------------------- ADICIONAR JOGO

@Composable
fun AddGameScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadLaunchable(ctx) } }

    Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(0.4f).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                ScreenTitle("Adicionar jogo")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Buscar nos apps instalados") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                Text("Importar APK", fontWeight = FontWeight.SemiBold)
                Text(
                    "Escolher um APK no gerenciador de arquivos chega na próxima etapa.",
                    color = Muted, fontSize = 13.sp
                )
                Spacer(Modifier.height(8.dp))
                NeonButton("Escolher APK", {}, enabled = false)
            }
        }
        Box(Modifier.weight(0.6f).fillMaxHeight()) {
            val list = apps
            if (list == null) {
                Text("Carregando apps…", color = Muted)
            } else {
                val shown = list.filter { it.name.contains(query, ignoreCase = true) }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                    items(shown, key = { it.pkg }) { app ->
                        val added = app.pkg in GameLibrary.games
                        Row(
                            Modifier.fillMaxWidth().panel().padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(app.icon, null, Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(app.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(app.pkg, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (added) {
                                Icon(Icons.Filled.Check, "Já está na biblioteca", tint = Ok)
                            } else {
                                NeonButton("Adicionar", {
                                    GameLibrary.add(ctx, app.pkg)
                                    Toast.makeText(ctx, "${app.name} adicionado", Toast.LENGTH_SHORT).show()
                                })
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- CONTA

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = Muted, modifier = Modifier.weight(1f))
        Text(value)
    }
}

@Composable
fun AccountScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        ScreenTitle("Conta")
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Sem login por enquanto", fontWeight = FontWeight.SemiBold)
                    Text("Sua biblioteca fica salva só neste aparelho.", color = Muted, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    InfoLine("Aparelho", "${Build.MANUFACTURER} ${Build.MODEL}")
                    InfoLine("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                    InfoLine("Jogos na biblioteca", GameLibrary.games.size.toString())
                    InfoLine("Versão do app", "0.6.0")
                }
            }
            Column(
                Modifier.weight(1f).panel().padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Logo()
                Spacer(Modifier.height(8.dp))
                CreatorSignature()
            }
        }
    }
}

// ---------------------------------------------------------------- CONFIGURAÇÕES

@Composable
private fun SegCell(text: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (on) Red else Surface2)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 13.sp, maxLines = 1, softWrap = false, color = if (on) Color.White else Ink)
    }
}

/** Quatro opções em grade 2x2, sempre com texto inteiro e legível. */
@Composable
private fun SegGrid(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (row in 0 until (options.size + 1) / 2) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (col in 0..1) {
                    val i = row * 2 + col
                    if (i < options.size) {
                        SegCell(options[i], i == selected, Modifier.weight(1f)) { onSelect(i) }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val on = MapperService.enabled
    var barMode by remember { mutableIntStateOf(ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).getInt("bar_mode", 0)) }
    var askImport by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) Toast.makeText(ctx, Backup.export(ctx, uri), Toast.LENGTH_LONG).show()
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) Toast.makeText(ctx, Backup.import(ctx, uri), Toast.LENGTH_LONG).show()
    }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        ScreenTitle("Configurações")
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Serviço do mapeador", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Ele faz os toques no jogo quando você aperta as teclas e mostra a coroa sobre o jogo.",
                        color = Muted, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Acessibilidade")
                            Text(if (on) "Ligado" else "Desligado", color = if (on) Ok else Muted, fontSize = 12.sp)
                        }
                        NeonButton("Abrir ajustes", {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Não consegue ligar?", fontWeight = FontWeight.SemiBold)
                    Text(
                        "No Android 13 ou mais novo, o sistema bloqueia serviços de apps instalados fora da Play Store. " +
                            "Abra as informações do app, toque nos 3 pontinhos e escolha “Permitir configurações restritas”.",
                        color = Muted, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    NeonButton("Abrir informações do app", {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        )
                    })
                }
            }
            Column(Modifier.weight(1f)) {
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Barra sobre o jogo", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Mostra a bateria e o estado do mouse e do teclado. Você arrasta a barra no jogo e a posição fica salva.",
                        color = Muted, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    SegGrid(listOf("Visível", "Discreta", "Transparente", "Oculta"), barMode) {
                        barMode = it
                        ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putInt("bar_mode", it).apply()
                    }
                    Spacer(Modifier.height(10.dp))
                    NeonButton("Restaurar posição da barra", {
                        ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).edit().remove("bar_x").remove("bar_y").apply()
                        Toast.makeText(ctx, "Posição restaurada", Toast.LENGTH_SHORT).show()
                    })
                }
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Backup e restauração", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Salva seus keymaps, perfis e configurações em um arquivo ZIP, no lugar que você escolher. Só neste aparelho, sem conta e sem nuvem.",
                        color = Muted, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    NeonButton("Exportar backup", { exportLauncher.launch("santos-mouse-gg-backup.zip") })
                    Spacer(Modifier.height(8.dp))
                    NeonButton("Importar backup", { askImport = true })
                }
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Como usar", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "1. Adicione o jogo e toque em Iniciar.\n" +
                            "2. Toque na coroa e em Editar keymap.\n" +
                            "3. Toque numa bolinha, aperte a tecla e arraste até o botão do jogo.\n" +
                            "4. Toque em SALVAR KEYMAP.",
                        color = Muted, fontSize = 13.sp
                    )
                }
            }
        }
    }
    if (askImport) {
        AlertDialog(
            onDismissRequest = { askImport = false },
            title = { Text("Importar backup?") },
            text = { Text("Seus keymaps e configurações atuais serão substituídos pelos do arquivo. Se o arquivo for inválido, nada muda.") },
            confirmButton = {
                TextButton(onClick = {
                    askImport = false
                    importLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                }) { Text("Escolher arquivo", color = Red) }
            },
            dismissButton = { TextButton(onClick = { askImport = false }) { Text("Cancelar") } }
        )
    }
}

// ---------------------------------------------------------------- ASSINATURA

@Composable
fun CreatorSignature(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("DESENVOLVEDOR", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Row(
            Modifier.clickable {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/santoss.56/")))
            }.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            InstagramGlyph(Modifier.size(16.dp), Muted)
            Spacer(Modifier.width(6.dp))
            Text("@santoss.56", color = Muted, fontSize = 12.sp)
        }
    }
}
