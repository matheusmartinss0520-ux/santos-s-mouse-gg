package br.com.santosmousegg

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- JOGOS

@Composable
private fun StatusLine(label: String, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(if (on) Ok else Muted, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, color = if (on) Ink else Muted)
    }
}

@Composable
fun GamesScreen(onAdd: () -> Unit) {
    val ctx = LocalContext.current
    remember { GameLibrary.load(ctx) }
    val input = rememberInputStatus()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle("Jogos", Modifier.weight(1f))
            NeonButton("+ Adicionar jogo", onAdd)
        }
        Spacer(Modifier.height(12.dp))
        Column(
            Modifier.fillMaxWidth().panel().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusLine("Mapeador desligado (chega na etapa 2)", false)
            StatusLine(if (input.mouse) "Mouse conectado" else "Mouse desconectado", input.mouse)
            StatusLine(if (input.keyboard) "Teclado conectado" else "Teclado desconectado", input.keyboard)
        }
        Spacer(Modifier.height(12.dp))
        val games = GameLibrary.games
        if (games.isEmpty()) {
            Text(
                "Sua biblioteca está vazia. Toque em “+ Adicionar jogo” para escolher um jogo instalado no celular.",
                color = Muted
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(games.toList(), key = { it }) { GameRow(it) }
            }
        }
    }
}

@Composable
private fun GameRow(pkg: String) {
    val ctx = LocalContext.current
    val info = remember(pkg) { appInfoOrNull(ctx, pkg) }
    var confirm by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().panel().padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (info != null) {
            Image(info.icon, null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
        } else {
            Box(Modifier.size(48.dp).background(Surface2, RoundedCornerShape(12.dp)))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(info?.name ?: pkg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (info != null) "Instalado" else "Não instalado",
                color = if (info != null) Ok else Muted,
                fontSize = 12.sp
            )
        }
        IconButton(onClick = { confirm = true }) {
            Icon(Icons.Filled.Delete, "Remover da biblioteca", tint = Muted)
        }
        NeonButton("Iniciar", {
            if (!launchApp(ctx, pkg)) {
                Toast.makeText(ctx, "Não foi possível abrir o jogo", Toast.LENGTH_SHORT).show()
            }
        }, enabled = info != null)
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Remover da biblioteca?") },
            text = { Text("O jogo continua instalado no celular. Ele só sai da lista do Santos Mouse GG.") },
            confirmButton = {
                TextButton(onClick = { GameLibrary.remove(ctx, pkg); confirm = false }) {
                    Text("Remover", color = Red)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } }
        )
    }
}

// ---------------------------------------------------------------- ADICIONAR JOGO

@Composable
fun AddGameScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadLaunchable(ctx) } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
            ScreenTitle("Adicionar jogo")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Buscar nos apps instalados") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        val list = apps
        if (list == null) {
            Text("Carregando apps…", color = Muted)
        } else {
            val shown = list.filter { it.name.contains(query, ignoreCase = true) }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                        Text("Importar APK", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Escolher um APK no gerenciador de arquivos chega na etapa 2.",
                            color = Muted, fontSize = 13.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        NeonButton("Escolher APK", {}, enabled = false)
                    }
                }
                items(shown, key = { it.pkg }) { app ->
                    val added = app.pkg in GameLibrary.games
                    Row(
                        Modifier.fillMaxWidth().panel().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(app.icon, null, Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(app.pkg, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (added) {
                            Icon(Icons.Filled.Check, "Já está na biblioteca", tint = Ok)
                        } else {
                            NeonButton("Adicionar", {
                                GameLibrary.add(ctx, app.pkg)
                                Toast.makeText(ctx, "${app.name} adicionado", Toast.LENGTH_SHORT).show()
                            })
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- CLONADOR

@Composable
fun ClonerScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        ScreenTitle("Clonador")
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
            Text("Clones criados (0)", fontWeight = FontWeight.SemiBold)
            Text("Você ainda não criou nenhum clone.", color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
            Text("Por que ainda não clona?", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Clonar um app exige um motor de virtualização, que vamos montar em uma etapa só dele. " +
                    "Nem todo app é compatível (APKs divididos, serviços do Google, proteção anti-cheat), " +
                    "e o app vai avisar quando um clone não for possível. Seus apps originais nunca são alterados.",
                color = Muted, fontSize = 13.sp
            )
        }
    }
}

// ---------------------------------------------------------------- CONTA

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = Muted, modifier = Modifier.weight(1f))
        Text(value)
    }
}

@Composable
fun AccountScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        ScreenTitle("Conta")
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
            Text("Sem login por enquanto", fontWeight = FontWeight.SemiBold)
            Text("Sua biblioteca fica salva só neste aparelho.", color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
            InfoLine("Aparelho", "${Build.MANUFACTURER} ${Build.MODEL}")
            InfoLine("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            InfoLine("Jogos na biblioteca", GameLibrary.games.size.toString())
            InfoLine("Versão do app", "0.1.0")
        }
    }
}

// ---------------------------------------------------------------- CONFIGURAÇÕES

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val overlay = remember(tick) { Settings.canDrawOverlays(ctx) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        ScreenTitle("Configurações")
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
            Text("Permissões do mapeador", fontWeight = FontWeight.SemiBold)
            Text("Serão usadas na etapa 2, para mostrar os controles sobre o jogo.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Sobreposição de tela")
                    Text(if (overlay) "Permitida" else "Não permitida", color = if (overlay) Ok else Muted, fontSize = 12.sp)
                }
                NeonButton("Abrir ajustes", {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                })
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
            Text("Ajuda", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Para jogar, adicione o jogo na aba Jogos e toque em Iniciar. " +
                    "O mouse e o teclado aparecem como conectados quando o Android os reconhece.",
                color = Muted, fontSize = 13.sp
            )
        }
    }
}
