package br.com.santosmousegg

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Uma tecla ou botão do mouse. x e y são frações da tela (0 a 1), size é o diâmetro em dp.
 * code > 0: tecla do teclado. code de -1 a -5: botões do mouse (esquerdo, direito, rodinha, lateral 1 e 2).
 */
class KeyDef(var code: Int, var label: String, var x: Float, var y: Float, var size: Int = 44)

/** Joystick de movimentação (digital, 8 direções, controlado por 4 teclas). */
class JoyDef(var x: Float, var y: Float, var radius: Int, var up: Int, var left: Int, var down: Int, var right: Int)

/** Componente de câmera: uma bolinha sobre o botão Visualizar do jogo. */
class CamDef(var x: Float, var y: Float, var radius: Int)

/** Tudo que é salvo por jogo: teclas, joystick, câmera, aparência e sensibilidade. */
class Keymap {
    val keys = mutableListOf<KeyDef>()
    var joy: JoyDef? = null
    var cam: CamDef? = null
    var mode = 0        // 0 visível, 1 discreto, 2 transparente, 3 oculto
    var opacity = 85    // 0 a 100
    var keySize = 44    // tamanho padrão das teclas novas (dp)
    var color = 0       // índice em COLORS

    // sensibilidade (porcentagens; 100 = normal)
    var sensG = 100
    var sensX = 100
    var sensY = 100
    var sensC = 100
    var accel = 0       // 0 a 100
    var prec = 0        // 0 a 100 (movimentos lentos ficam mais finos)
    var invY = false

    // alternância cursor / câmera
    var fastKey = 0     // libera o cursor por um instante e volta sozinho
    var manualKey = 0   // libera o cursor até apertar de novo
    var fastMs = 700

    fun copy(): Keymap = fromJson(toJson())

    fun toJson(): String {
        val o = JSONObject()
        o.put("mode", mode)
        o.put("opacity", opacity)
        o.put("keySize", keySize)
        o.put("color", color)
        o.put("sensG", sensG)
        o.put("sensX", sensX)
        o.put("sensY", sensY)
        o.put("sensC", sensC)
        o.put("accel", accel)
        o.put("prec", prec)
        o.put("invY", invY)
        o.put("fastKey", fastKey)
        o.put("manualKey", manualKey)
        o.put("fastMs", fastMs)
        val ka = JSONArray()
        for (k in keys) {
            val ko = JSONObject()
            ko.put("c", k.code)
            ko.put("l", k.label)
            ko.put("x", k.x.toDouble())
            ko.put("y", k.y.toDouble())
            ko.put("s", k.size)
            ka.put(ko)
        }
        o.put("keys", ka)
        val j = joy
        if (j != null) {
            val jo = JSONObject()
            jo.put("x", j.x.toDouble())
            jo.put("y", j.y.toDouble())
            jo.put("r", j.radius)
            jo.put("u", j.up)
            jo.put("l", j.left)
            jo.put("d", j.down)
            jo.put("rt", j.right)
            o.put("joy", jo)
        }
        val c = cam
        if (c != null) {
            val co = JSONObject()
            co.put("x", c.x.toDouble())
            co.put("y", c.y.toDouble())
            co.put("r", c.radius)
            o.put("cam", co)
        }
        return o.toString()
    }

    companion object {
        val COLORS = intArrayOf(
            0xFFE5202E.toInt(), 0xFFFF6A00.toInt(), 0xFFB517FF.toInt(), 0xFF12B5FF.toInt(), 0xFF1FD16B.toInt()
        )

        fun fromJson(s: String?): Keymap {
            val k = Keymap()
            if (s.isNullOrBlank()) return k
            try {
                val o = JSONObject(s)
                k.mode = o.optInt("mode", 0)
                k.opacity = o.optInt("opacity", 85)
                k.keySize = o.optInt("keySize", 44)
                k.color = o.optInt("color", 0)
                k.sensG = o.optInt("sensG", 100)
                k.sensX = o.optInt("sensX", 100)
                k.sensY = o.optInt("sensY", 100)
                k.sensC = o.optInt("sensC", 100)
                k.accel = o.optInt("accel", 0)
                k.prec = o.optInt("prec", 0)
                k.invY = o.optBoolean("invY", false)
                k.fastKey = o.optInt("fastKey", 0)
                k.manualKey = o.optInt("manualKey", 0)
                k.fastMs = o.optInt("fastMs", 700)
                val ka = o.optJSONArray("keys")
                if (ka != null) {
                    for (i in 0 until ka.length()) {
                        val ko = ka.getJSONObject(i)
                        k.keys.add(
                            KeyDef(
                                ko.getInt("c"), ko.getString("l"),
                                ko.getDouble("x").toFloat(), ko.getDouble("y").toFloat(),
                                ko.optInt("s", k.keySize)
                            )
                        )
                    }
                }
                val jo = o.optJSONObject("joy")
                if (jo != null) {
                    k.joy = JoyDef(
                        jo.getDouble("x").toFloat(), jo.getDouble("y").toFloat(), jo.getInt("r"),
                        jo.getInt("u"), jo.getInt("l"), jo.getInt("d"), jo.getInt("rt")
                    )
                }
                val co = o.optJSONObject("cam")
                if (co != null) {
                    k.cam = CamDef(co.getDouble("x").toFloat(), co.getDouble("y").toFloat(), co.getInt("r"))
                }
            } catch (e: Exception) {
                // dado ilegível: começa vazio, sem derrubar o app
            }
            return k
        }
    }
}

/**
 * Três estados separados por jogo:
 * salvo (o oficial, usado no jogo), edição temporária (só na memória) e rascunho (cópia de recuperação).
 */
object LayoutStore {
    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("keymaps_v2", Context.MODE_PRIVATE)

    fun loadSaved(ctx: Context, pkg: String): Keymap = Keymap.fromJson(p(ctx).getString("saved:$pkg", null))

    fun save(ctx: Context, pkg: String, k: Keymap) {
        p(ctx).edit().putString("saved:$pkg", k.toJson()).commit()
    }

    fun draft(ctx: Context, pkg: String): Keymap? {
        val s = p(ctx).getString("draft:$pkg", null) ?: return null
        return Keymap.fromJson(s)
    }

    fun saveDraft(ctx: Context, pkg: String, k: Keymap) {
        p(ctx).edit().putString("draft:$pkg", k.toJson()).apply()
    }

    fun clearDraft(ctx: Context, pkg: String) {
        p(ctx).edit().remove("draft:$pkg").apply()
    }
}
