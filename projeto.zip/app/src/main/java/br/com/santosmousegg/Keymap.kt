package br.com.santosmousegg

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Uma tecla do keymap. x e y são frações da tela (0 a 1). */
class KeyDef(var code: Int, var label: String, var x: Float, var y: Float)

/** Joystick de movimentação (digital, 8 direções, controlado por 4 teclas). */
class JoyDef(var x: Float, var y: Float, var radius: Int, var up: Int, var left: Int, var down: Int, var right: Int)

/** Tudo que é salvo por jogo: teclas, joystick e aparência. */
class Keymap {
    val keys = mutableListOf<KeyDef>()
    var joy: JoyDef? = null
    var mode = 0        // 0 visível, 1 discreto, 2 transparente, 3 oculto
    var opacity = 85    // 0 a 100
    var keySize = 44    // dp
    var color = 0       // índice em COLORS

    fun copy(): Keymap = fromJson(toJson())

    fun toJson(): String {
        val o = JSONObject()
        o.put("mode", mode)
        o.put("opacity", opacity)
        o.put("keySize", keySize)
        o.put("color", color)
        val ka = JSONArray()
        for (k in keys) {
            val ko = JSONObject()
            ko.put("c", k.code)
            ko.put("l", k.label)
            ko.put("x", k.x.toDouble())
            ko.put("y", k.y.toDouble())
            ka.put(ko)
        }
        o.put("keys", ka)
        val j = joy
        if (j != null) {
            val jo = JSONObject()
            jo.put("x", j.x.toDouble())
            jo.put("y", j.y.toDouble())
            jo.put("r", j.radius)
            jo.put("u", j.up)
            jo.put("l", j.left)
            jo.put("d", j.down)
            jo.put("rt", j.right)
            o.put("joy", jo)
        }
        return o.toString()
    }

    companion object {
        val COLORS = intArrayOf(
            0xFFE5202E.toInt(), 0xFFFF6A00.toInt(), 0xFFB517FF.toInt(), 0xFF12B5FF.toInt(), 0xFF1FD16B.toInt()
        )

        fun fromJson(s: String?): Keymap {
            val k = Keymap()
            if (s.isNullOrBlank()) return k
            try {
                val o = JSONObject(s)
                k.mode = o.optInt("mode", 0)
                k.opacity = o.optInt("opacity", 85)
                k.keySize = o.optInt("keySize", 44)
                k.color = o.optInt("color", 0)
                val ka = o.optJSONArray("keys")
                if (ka != null) {
                    for (i in 0 until ka.length()) {
                        val ko = ka.getJSONObject(i)
                        k.keys.add(
                            KeyDef(
                                ko.getInt("c"), ko.getString("l"),
                                ko.getDouble("x").toFloat(), ko.getDouble("y").toFloat()
                            )
                        )
                    }
                }
                val jo = o.optJSONObject("joy")
                if (jo != null) {
                    k.joy = JoyDef(
                        jo.getDouble("x").toFloat(), jo.getDouble("y").toFloat(), jo.getInt("r"),
                        jo.getInt("u"), jo.getInt("l"), jo.getInt("d"), jo.getInt("rt")
                    )
                }
            } catch (e: Exception) {
                // dado ilegível: começa vazio, sem derrubar o app
            }
            return k
        }
    }
}

/**
 * Três estados separados por jogo:
 * salvo (o oficial, usado no jogo), edição temporária (só na memória) e rascunho (cópia de recuperação).
 */
object LayoutStore {
    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("keymaps_v2", Context.MODE_PRIVATE)

    fun loadSaved(ctx: Context, pkg: String): Keymap = Keymap.fromJson(p(ctx).getString("saved:$pkg", null))

    fun save(ctx: Context, pkg: String, k: Keymap) {
        p(ctx).edit().putString("saved:$pkg", k.toJson()).commit()
    }

    fun draft(ctx: Context, pkg: String): Keymap? {
        val s = p(ctx).getString("draft:$pkg", null) ?: return null
        return Keymap.fromJson(s)
    }

    fun saveDraft(ctx: Context, pkg: String, k: Keymap) {
        p(ctx).edit().putString("draft:$pkg", k.toJson()).apply()
    }

    fun clearDraft(ctx: Context, pkg: String) {
        p(ctx).edit().remove("draft:$pkg").apply()
    }
}
