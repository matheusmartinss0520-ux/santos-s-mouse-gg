package br.com.santosmousegg

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup manual e local em ZIP. Guarda só as configurações do app (keymaps, perfis, biblioteca e preferências).
 * Nunca inclui APKs, senhas ou permissões. O ZIP tem só dois arquivos fixos, então não há como escrever fora do app.
 */
object Backup {
    private const val APP = "SantosMouseGG"
    private const val VERSION = 1
    private const val MAX_BYTES = 5 * 1024 * 1024
    private val PREFS = listOf("keymaps_v2", "ui", "library")
    private val KEY_OK = Regex("^[A-Za-z0-9:._-]{1,200}$")

    private fun dump(ctx: Context): JSONObject {
        val root = JSONObject()
        for (name in PREFS) {
            val p = ctx.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
            val o = JSONObject()
            for ((k, v) in p.all) {
                when (v) {
                    is String -> o.put(k, JSONObject().put("t", "s").put("v", v))
                    is Int -> o.put(k, JSONObject().put("t", "i").put("v", v))
                    is Boolean -> o.put(k, JSONObject().put("t", "b").put("v", v))
                    else -> { }
                }
            }
            root.put(name, o)
        }
        return root
    }

    private fun sha(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    fun export(ctx: Context, uri: Uri): String {
        return try {
            val data = dump(ctx).toString().toByteArray(Charsets.UTF_8)
            val manifest = JSONObject()
                .put("app", APP)
                .put("version", VERSION)
                .put("created", System.currentTimeMillis())
                .put("sha256", sha(data))
                .toString().toByteArray(Charsets.UTF_8)
            val out = ctx.contentResolver.openOutputStream(uri) ?: return "Não foi possível abrir o destino"
            out.use { os ->
                ZipOutputStream(os).use { z ->
                    z.putNextEntry(ZipEntry("manifest.json"))
                    z.write(manifest)
                    z.closeEntry()
                    z.putNextEntry(ZipEntry("data.json"))
                    z.write(data)
                    z.closeEntry()
                }
            }
            "Backup salvo com sucesso"
        } catch (e: Exception) {
            "Não foi possível salvar o backup"
        }
    }

    private fun validate(data: JSONObject) {
        val names = data.keys()
        while (names.hasNext()) {
            val name = names.next()
            if (name !in PREFS) throw IllegalArgumentException("pref")
            val o = data.getJSONObject(name)
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                if (!KEY_OK.matches(k)) throw IllegalArgumentException("chave")
                val e = o.getJSONObject(k)
                when (e.getString("t")) {
                    "s" -> {
                        val v = e.getString("v")
                        if (v.length > MAX_BYTES) throw IllegalArgumentException("tamanho")
                        if (k.startsWith("saved:") || k.startsWith("draft:")) JSONObject(v)
                    }
                    "i" -> e.getInt("v")
                    "b" -> e.getBoolean("v")
                    else -> throw IllegalArgumentException("tipo")
                }
            }
        }
    }

    private fun apply(ctx: Context, data: JSONObject) {
        for (name in PREFS) {
            val o = data.optJSONObject(name) ?: JSONObject()
            val ed = ctx.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE).edit()
            ed.clear()
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val e = o.getJSONObject(k)
                when (e.getString("t")) {
                    "s" -> ed.putString(k, e.getString("v"))
                    "i" -> ed.putInt(k, e.getInt("v"))
                    "b" -> ed.putBoolean(k, e.getBoolean("v"))
                }
            }
            if (!ed.commit()) throw IllegalStateException("commit")
        }
    }

    fun import(ctx: Context, uri: Uri): String {
        val files = HashMap<String, ByteArray>()
        try {
            val ins = ctx.contentResolver.openInputStream(uri) ?: return "Não foi possível abrir o arquivo"
            ins.use { s ->
                ZipInputStream(s).use { z ->
                    var count = 0
                    var entry: ZipEntry? = z.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        count++
                        if (count > 2 || (name != "manifest.json" && name != "data.json")) {
                            return "Arquivo inválido: conteúdo inesperado"
                        }
                        val buf = ByteArrayOutputStream()
                        val tmp = ByteArray(8192)
                        var total = 0
                        while (true) {
                            val n = z.read(tmp)
                            if (n < 0) break
                            total += n
                            if (total > MAX_BYTES) return "Arquivo inválido: grande demais"
                            buf.write(tmp, 0, n)
                        }
                        files[name] = buf.toByteArray()
                        z.closeEntry()
                        entry = z.nextEntry
                    }
                }
            }
        } catch (e: Exception) {
            return "Arquivo inválido ou corrompido"
        }
        val mBytes = files["manifest.json"]
        val dBytes = files["data.json"]
        if (mBytes == null || dBytes == null) return "Arquivo inválido: faltam partes do backup"
        val data: JSONObject
        try {
            val m = JSONObject(String(mBytes, Charsets.UTF_8))
            if (m.getString("app") != APP) return "Esse arquivo não é um backup do Santos Mouse GG"
            val v = m.getInt("version")
            if (v < 1 || v > VERSION) return "Backup de uma versão incompatível"
            if (m.getString("sha256") != sha(dBytes)) return "Backup corrompido (verificação falhou)"
            data = JSONObject(String(dBytes, Charsets.UTF_8))
            validate(data)
        } catch (e: Exception) {
            return "Arquivo inválido ou incompatível"
        }
        val before = dump(ctx)
        try {
            apply(ctx, data)
        } catch (e: Exception) {
            try { apply(ctx, before) } catch (e2: Exception) { }
            return "A restauração falhou. Seus dados anteriores foram mantidos"
        }
        GameLibrary.reload(ctx)
        return "Backup restaurado com sucesso"
    }
}
